/*
 * IEEE 802.11 Common routines
 * Copyright (c) 2002-2019, Jouni Malinen <j@w1.fi>
 *
 * This software may be distributed under the terms of the BSD license.
 * See README for more details.
 */

#include "includes.h"

#include "common.h"
#include "defs.h"
#include "wpa_common.h"
#include "drivers/driver.h"
#include "qca-vendor.h"
#include "ieee802_11_defs.h"
#include "ieee802_11_common.h"


static int ieee802_11_parse_vendor_specific(const u8 *pos, size_t elen,
					    struct ieee802_11_elems *elems,
					    int show_errors)
{
	unsigned int oui;

	/* first 3 bytes in vendor specific information element are the IEEE
	 * OUI of the vendor. The following byte is used a vendor specific
	 * sub-type. */
	if (elen < 4) {
		if (show_errors) {
			wpa_printf(MSG_MSGDUMP, "short vendor specific "
				   "information element ignored (len=%lu)",
				   (unsigned long) elen);
		}
		return -1;
	}

	oui = WPA_GET_BE24(pos);
	switch (oui) {
	case OUI_MICROSOFT:
		/* Microsoft/Wi-Fi information elements are further typed and
		 * subtyped */
		switch (pos[3]) {
		case 1:
			/* Microsoft OUI (00:50:F2) with OUI Type 1:
			 * real WPA information element */
			elems->wpa_ie = pos;
			elems->wpa_ie_len = elen;
			break;
		case WMM_OUI_TYPE:
			/* WMM information element */
			if (elen < 5) {
				wpa_printf(MSG_MSGDUMP, "short WMM "
					   "information element ignored "
					   "(len=%lu)",
					   (unsigned long) elen);
				return -1;
			}
			switch (pos[4]) {
			case WMM_OUI_SUBTYPE_INFORMATION_ELEMENT:
			case WMM_OUI_SUBTYPE_PARAMETER_ELEMENT:
				/*
				 * Share same pointer since only one of these
				 * is used and they start with same data.
				 * Length field can be used to distinguish the
				 * IEs.
				 */
				elems->wmm = pos;
				elems->wmm_len = elen;
				break;
			case WMM_OUI_SUBTYPE_TSPEC_ELEMENT:
				elems->wmm_tspec = pos;
				elems->wmm_tspec_len = elen;
				break;
			default:
				wpa_printf(MSG_EXCESSIVE, "unknown WMM "
					   "information element ignored "
					   "(subtype=%d len=%lu)",
					   pos[4], (unsigned long) elen);
				return -1;
			}
			break;
		case 4:
			/* Wi-Fi Protected Setup (WPS) IE */
			elems->wps_ie = pos;
			elems->wps_ie_len = elen;
			break;
		default:
			wpa_printf(MSG_EXCESSIVE, "Unknown Microsoft "
				   "information element ignored "
				   "(type=%d len=%lu)",
				   pos[3], (unsigned long) elen);
			return -1;
		}
		break;

	case OUI_WFA:
		switch (pos[3]) {
		case P2P_OUI_TYPE:
			/* Wi-Fi Alliance - P2P IE */
			elems->p2p = pos;
			elems->p2p_len = elen;
			break;
		case WFD_OUI_TYPE:
			/* Wi-Fi Alliance - WFD IE */
			elems->wfd = pos;
			elems->wfd_len = elen;
			break;
		case HS20_INDICATION_OUI_TYPE:
			/* Hotspot 2.0 */
			elems->hs20 = pos;
			elems->hs20_len = elen;
			break;
		case MBO_OUI_TYPE:
			/* MBO-OCE */
			elems->mbo = pos;
			elems->mbo_len = elen;
			break;
		case HS20_ROAMING_CONS_SEL_OUI_TYPE:
			/* Hotspot 2.0 Roaming Consortium Selection */
			elems->roaming_cons_sel = pos;
			elems->roaming_cons_sel_len = elen;
			break;
		case MULTI_AP_OUI_TYPE:
			elems->multi_ap = pos;
			elems->multi_ap_len = elen;
			break;
		case OWE_OUI_TYPE:
			/* OWE Transition Mode element */
			break;
		case DPP_CC_OUI_TYPE:
			/* DPP Configurator Connectivity element */
			break;
		case SAE_PK_OUI_TYPE:
			elems->sae_pk = pos + 4;
			elems->sae_pk_len = elen - 4;
			break;
		case WFA_CAPA_OUI_TYPE:
			elems->wfa_capab = pos + 4;
			elems->wfa_capab_len = elen - 4;
			break;
		case WFA_RSNE_OVERRIDE_OUI_TYPE:
			elems->rsne_override = pos;
			elems->rsne_override_len = elen;
			break;
		case WFA_RSNE_OVERRIDE_2_OUI_TYPE:
			elems->rsne_override_2 = pos;
			elems->rsne_override_2_len = elen;
			break;
		case WFA_RSNXE_OVERRIDE_OUI_TYPE:
			elems->rsnxe_override = pos;
			elems->rsnxe_override_len = elen;
			break;
		case WFA_RSN_SELECTION_OUI_TYPE:
			if (elen < 4 + 1) {
				wpa_printf(MSG_DEBUG,
					   "Too short RSN Selection element ignored");
				return -1;
			}
			elems->rsn_selection = pos + 4;
			elems->rsn_selection_len = elen - 4;
			break;
		case P2P2_OUI_TYPE:
			/* Wi-Fi Alliance - P2P2 IE */
			elems->p2p2_ie = pos;
			elems->p2p2_ie_len = elen;
			break;
		case PR_OUI_TYPE:
			/* Wi-Fi Alliance - Proximity Ranging element */
			elems->proximity_ranging = pos;
			elems->proximity_ranging_len = elen;
			break;
		case NAN_SDF_OUI_TYPE:
			/* Wi-Fi Alliance - NAN IE */
			elems->nan_ie = pos;
			elems->nan_len = elen;
			break;
		default:
			wpa_printf(MSG_MSGDUMP, "Unknown WFA "
				   "information element ignored "
				   "(type=%d len=%lu)",
				   pos[3], (unsigned long) elen);
			return -1;
		}
		break;

	case OUI_BROADCOM:
		switch (pos[3]) {
		case VENDOR_HT_CAPAB_OUI_TYPE:
			elems->vendor_ht_cap = pos;
			elems->vendor_ht_cap_len = elen;
			break;
		case VENDOR_VHT_TYPE:
			if (elen > 4 &&
			    (pos[4] == VENDOR_VHT_SUBTYPE ||
			     pos[4] == VENDOR_VHT_SUBTYPE2)) {
				elems->vendor_vht = pos;
				elems->vendor_vht_len = elen;
			} else
				return -1;
			break;
		default:
			wpa_printf(MSG_EXCESSIVE, "Unknown Broadcom "
				   "information element ignored "
				   "(type=%d len=%lu)",
				   pos[3], (unsigned long) elen);
			return -1;
		}
		break;

	case OUI_QCA:
		switch (pos[3]) {
		case QCA_VENDOR_ELEM_P2P_PREF_CHAN_LIST:
			elems->pref_freq_list = pos;
			elems->pref_freq_list_len = elen;
			break;
		default:
			wpa_printf(MSG_EXCESSIVE,
				   "Unknown QCA information element ignored (type=%d len=%lu)",
				   pos[3], (unsigned long) elen);
			return -1;
		}
		break;

	default:
		wpa_printf(MSG_EXCESSIVE, "unknown vendor specific "
			   "information element ignored (vendor OUI "
			   "%02x:%02x:%02x len=%lu)",
			   pos[0], pos[1], pos[2], (unsigned long) elen);
		return -1;
	}

	return 0;
}


static int ieee802_11_parse_mle(const u8 *pos, size_t elen, size_t **total_len,
				struct ieee802_11_elems *elems,
				int show_errors)
{
	u8 mle_type = pos[0] & MULTI_LINK_CONTROL_TYPE_MASK;

	switch (mle_type) {
	case MULTI_LINK_CONTROL_TYPE_BASIC:
		elems->basic_mle = pos;
		elems->basic_mle_len = elen;
		*total_len = &elems->basic_mle_len;
		break;
	case MULTI_LINK_CONTROL_TYPE_PROBE_REQ:
		elems->probe_req_mle = pos;
		elems->probe_req_mle_len = elen;
		*total_len = &elems->probe_req_mle_len;
		break;
	case MULTI_LINK_CONTROL_TYPE_RECONF:
		elems->reconf_mle = pos;
		elems->reconf_mle_len = elen;
		*total_len = &elems->reconf_mle_len;
		break;
	case MULTI_LINK_CONTROL_TYPE_TDLS:
		elems->tdls_mle = pos;
		elems->tdls_mle_len = elen;
		*total_len = &elems->tdls_mle_len;
		break;
	case MULTI_LINK_CONTROL_TYPE_PRIOR_ACCESS:
		elems->prior_access_mle = pos;
		elems->prior_access_mle_len = elen;
		*total_len = &elems->prior_access_mle_len;
		break;
	default:
		if (show_errors) {
			wpa_printf(MSG_MSGDUMP,
				   "Unknown Multi-Link element type %u",
				   mle_type);
		}
		return -1;
	}

	return 0;
}


static size_t ieee802_11_fragments_length(struct ieee802_11_elems *elems,
					  const u8 *start, size_t len)
{
	const struct element *elem;
	size_t frags_len = 0;

	for_each_element(elem, start, len) {
		if (elem->id != WLAN_EID_FRAGMENT)
			break;

		frags_len += elem->datalen + 2;
		elems->num_frag_elems++;
	}

	return frags_len;
}


static int ieee802_11_parse_extension(const u8 *pos, size_t elen,
				      struct ieee802_11_elems *elems,
				      const u8 *start, size_t len,
				      int show_errors)
{
	u8 ext_id;
	size_t *total_len = NULL;

	if (elen < 1) {
		if (show_errors) {
			wpa_printf(MSG_MSGDUMP,
				   "short information element (Ext)");
		}
		return -1;
	}

	ext_id = *pos++;
	elen--;

	switch (ext_id) {
	case WLAN_EID_EXT_ASSOC_DELAY_INFO:
		if (elen != 1)
			break;
		elems->assoc_delay_info = pos;
		break;
	case WLAN_EID_EXT_FILS_REQ_PARAMS:
		if (elen < 3)
			break;
		elems->fils_req_params = pos;
		elems->fils_req_params_len = elen;
		break;
	case WLAN_EID_EXT_FILS_KEY_CONFIRM:
		elems->fils_key_confirm = pos;
		elems->fils_key_confirm_len = elen;
		break;
	case WLAN_EID_EXT_FILS_SESSION:
		if (elen != FILS_SESSION_LEN)
			break;
		elems->fils_session = pos;
		break;
	case WLAN_EID_EXT_FILS_HLP_CONTAINER:
		if (elen < 2 * ETH_ALEN)
			break;
		elems->fils_hlp = pos;
		elems->fils_hlp_len = elen;
		total_len = &elems->fils_hlp_len;
		break;
	case WLAN_EID_EXT_FILS_IP_ADDR_ASSIGN:
		if (elen < 1)
			break;
		elems->fils_ip_addr_assign = pos;
		elems->fils_ip_addr_assign_len = elen;
		break;
	case WLAN_EID_EXT_KEY_DELIVERY:
		if (elen < WPA_KEY_RSC_LEN)
			break;
		elems->key_delivery = pos;
		elems->key_delivery_len = elen;
		total_len = &elems->key_delivery_len;
		break;
	case WLAN_EID_EXT_WRAPPED_DATA:
		elems->wrapped_data = pos;
		elems->wrapped_data_len = elen;
		total_len = &elems->wrapped_data_len;
		break;
	case WLAN_EID_EXT_FILS_PUBLIC_KEY:
		if (elen < 1)
			break;
		elems->fils_pk = pos;
		elems->fils_pk_len = elen;
		break;
	case WLAN_EID_EXT_NONCE:
		if (elen < NONCE_LEN)
			break;
		elems->nonce = pos;
		elems->nonce_len = elen;
		break;
	case WLAN_EID_EXT_OWE_DH_PARAM:
		if (elen < 2)
			break;
		elems->owe_dh = pos;
		elems->owe_dh_len = elen;
		break;
	case WLAN_EID_EXT_PASSWORD_IDENTIFIER:
		elems->password_id = pos;
		elems->password_id_len = elen;
		break;
	case WLAN_EID_EXT_HE_CAPABILITIES:
		if (elen < HE_CAPABILITIES_ELEM_MIN_LEN)
			break;
		elems->he_capabilities = pos;
		elems->he_capabilities_len = elen;
		break;
	case WLAN_EID_EXT_HE_OPERATION:
		if (elen < HE_OPERATION_ELEM_MIN_LEN)
			break;
		elems->he_operation = pos;
		elems->he_operation_len = elen;
		break;
	case WLAN_EID_EXT_OCV_OCI:
		elems->oci = pos;
		elems->oci_len = elen;
		break;
	case WLAN_EID_EXT_SHORT_SSID_LIST:
		elems->short_ssid_list = pos;
		elems->short_ssid_list_len = elen;
		break;
	case WLAN_EID_EXT_HE_6GHZ_BAND_CAP:
		if (elen < sizeof(struct ieee80211_he_6ghz_band_cap))
			break;
		elems->he_6ghz_band_cap = pos;
		break;
	case WLAN_EID_EXT_PASN_PARAMS:
		elems->pasn_params = pos;
		elems->pasn_params_len = elen;
		break;
	case WLAN_EID_EXT_EHT_CAPABILITIES:
		if (elen < EHT_CAPABILITIES_ELEM_MIN_LEN)
			break;
		elems->eht_capabilities = pos;
		elems->eht_capabilities_len = elen;
		break;
	case WLAN_EID_EXT_EHT_OPERATION:
		if (elen < EHT_OPERATION_ELEM_MIN_LEN)
			break;
		elems->eht_operation = pos;
		elems->eht_operation_len = elen;
		break;
	case WLAN_EID_EXT_MULTI_LINK:
		if (elen < 2)
			break;
		if (ieee802_11_parse_mle(pos, elen, &total_len, elems,
					 show_errors))
			return -1;
		break;
	case WLAN_EID_EXT_KNOWN_BSSID:
		elems->mbssid_known_bss = pos;
		elems->mbssid_known_bss_len = elen;
		break;
	case WLAN_EID_EXT_PASN_ENCRYPTED_DATA:
		elems->pasn_encrypted_data = pos;
		elems->pasn_encrypted_data_len = elen;
		break;
	case WLAN_EID_EXT_AKM_SUITE_SELECTOR:
		if (elen < RSN_SELECTOR_LEN)
			break;
		elems->akm_suite_selector = pos;
		elems->akm_suite_selector_len = elen;
		break;
	case WLAN_EID_EXT_SUPPORTED_GROUPS:
		if (elen < 2 || elen % 2 != 0)
			break;
		elems->supported_groups = pos;
		elems->supported_groups_len = elen;
		break;
	default:
		if (show_errors) {
			wpa_printf(MSG_MSGDUMP,
				   "IEEE 802.11 element parsing ignored unknown element extension (ext_id=%u elen=%u)",
				   ext_id, (unsigned int) elen);
		}
		return -1;
	}

	if (elen == 254 && total_len)
		*total_len += ieee802_11_fragments_length(
			elems, pos + elen, (start + len) - (pos + elen));

	return 0;
}


static ParseRes __ieee802_11_parse_elems(const u8 *start, size_t len,
					 struct ieee802_11_elems *elems,
					 int show_errors)
{
	const struct element *elem;
	int unknown = 0;

	if (!start)
		return ParseOK;

	for_each_element(elem, start, len) {
		u8 id = elem->id, elen = elem->datalen;
		const u8 *pos = elem->data;
		size_t *total_len = NULL;

		if (id == WLAN_EID_FRAGMENT && elems->num_frag_elems > 0) {
			elems->num_frag_elems--;
			continue;
		}
		elems->num_frag_elems = 0;

		switch (id) {
		case WLAN_EID_SSID:
			if (elen > SSID_MAX_LEN) {
				wpa_printf(MSG_DEBUG,
					   "Ignored too long SSID element (elen=%u)",
					   elen);
				break;
			}
			if (elems->ssid) {
				wpa_printf(MSG_MSGDUMP,
					   "Ignored duplicated SSID element");
				break;
			}
			elems->ssid = pos;
			elems->ssid_len = elen;
			break;
		case WLAN_EID_SUPP_RATES:
			elems->supp_rates = pos;
			elems->supp_rates_len = elen;
			break;
		case WLAN_EID_DS_PARAMS:
			if (elen < 1)
				break;
			elems->ds_params = pos;
			break;
		case WLAN_EID_CF_PARAMS:
		case WLAN_EID_TIM:
			break;
		case WLAN_EID_CHALLENGE:
			elems->challenge = pos;
			elems->challenge_len = elen;
			break;
		case WLAN_EID_ERP_INFO:
			if (elen < 1)
				break;
			elems->erp_info = pos;
			break;
		case WLAN_EID_EXT_SUPP_RATES:
			elems->ext_supp_rates = pos;
			elems->ext_supp_rates_len = elen;
			break;
		case WLAN_EID_VENDOR_SPECIFIC:
			if (ieee802_11_parse_vendor_specific(pos, elen,
							     elems,
							     show_errors))
				unknown++;
			break;
		case WLAN_EID_RSN:
			elems->rsn_ie = pos;
			elems->rsn_ie_len = elen;
			break;
		case WLAN_EID_RSNX:
			elems->rsnxe = pos;
			elems->rsnxe_len = elen;
			break;
		case WLAN_EID_PWR_CAPABILITY:
			if (elen < 2)
				break;
			elems->power_capab = pos;
			elems->power_capab_len = elen;
			break;
		case WLAN_EID_SUPPORTED_CHANNELS:
			elems->supp_channels = pos;
			elems->supp_channels_len = elen;
			break;
		case WLAN_EID_MOBILITY_DOMAIN:
			if (elen < sizeof(struct rsn_mdie))
				break;
			elems->mdie = pos;
			elems->mdie_len = elen;
			break;
		case WLAN_EID_FAST_BSS_TRANSITION:
			if (elen < sizeof(struct rsn_ftie))
				break;
			elems->ftie = pos;
			elems->ftie_len = elen;
			elems->fte_defrag_len = elen;
			total_len = &elems->fte_defrag_len;
			break;
		case WLAN_EID_TIMEOUT_INTERVAL:
			if (elen != 5)
				break;
			elems->timeout_int = pos;
			break;
		case WLAN_EID_HT_CAP:
			if (elen < sizeof(struct ieee80211_ht_capabilities))
				break;
			elems->ht_capabilities = pos;
			break;
		case WLAN_EID_HT_OPERATION:
			if (elen < sizeof(struct ieee80211_ht_operation))
				break;
			elems->ht_operation = pos;
			break;
		case WLAN_EID_MESH_CONFIG:
			elems->mesh_config = pos;
			elems->mesh_config_len = elen;
			break;
		case WLAN_EID_MESH_ID:
			elems->mesh_id = pos;
			elems->mesh_id_len = elen;
			break;
		case WLAN_EID_PEER_MGMT:
			elems->peer_mgmt = pos;
			elems->peer_mgmt_len = elen;
			break;
		case WLAN_EID_VHT_CAP:
			if (elen < sizeof(struct ieee80211_vht_capabilities))
				break;
			elems->vht_capabilities = pos;
			break;
		case WLAN_EID_VHT_OPERATION:
			if (elen < sizeof(struct ieee80211_vht_operation))
				break;
			elems->vht_operation = pos;
			break;
		case WLAN_EID_OPERATING_MODE_NOTIFICATION:
			if (elen != 1)
				break;
			elems->opmode_notif = pos;
			break;
		case WLAN_EID_LINK_ID:
			if (elen < 18)
				break;
			elems->link_id = pos;
			break;
		case WLAN_EID_INTERWORKING:
			elems->interworking = pos;
			elems->interworking_len = elen;
			break;
		case WLAN_EID_QOS_MAP_SET:
			if (elen < 16)
				break;
			elems->qos_map_set = pos;
			elems->qos_map_set_len = elen;
			break;
		case WLAN_EID_EXT_CAPAB:
			elems->ext_capab = pos;
			elems->ext_capab_len = elen;
			break;
		case WLAN_EID_BSS_MAX_IDLE_PERIOD:
			if (elen < 3)
				break;
			elems->bss_max_idle_period = pos;
			break;
		case WLAN_EID_SSID_LIST:
			elems->ssid_list = pos;
			elems->ssid_list_len = elen;
			break;
		case WLAN_EID_AMPE:
			elems->ampe = pos;
			elems->ampe_len = elen;
			break;
		case WLAN_EID_MIC:
			elems->mic = pos;
			elems->mic_len = elen;
			if (elems->stop_at_mic) {
				/* After MIC everything is encrypted, so stop.
				 */
				goto done;
			}
			break;
		case WLAN_EID_MULTI_BAND:
			if (elems->mb_ies.nof_ies >= MAX_NOF_MB_IES_SUPPORTED) {
				wpa_printf(MSG_MSGDUMP,
					   "IEEE 802.11 element parse ignored MB IE (id=%d elen=%d)",
					   id, elen);
				break;
			}

			elems->mb_ies.ies[elems->mb_ies.nof_ies].ie = pos;
			elems->mb_ies.ies[elems->mb_ies.nof_ies].ie_len = elen;
			elems->mb_ies.nof_ies++;
			break;
		case WLAN_EID_SUPPORTED_OPERATING_CLASSES:
			elems->supp_op_classes = pos;
			elems->supp_op_classes_len = elen;
			break;
		case WLAN_EID_RRM_ENABLED_CAPABILITIES:
			elems->rrm_enabled = pos;
			elems->rrm_enabled_len = elen;
			break;
		case WLAN_EID_MULTIPLE_BSSID:
			if (elen < 1)
				break;
			elems->mbssid = pos;
			elems->mbssid_len = elen;
			break;
		case WLAN_EID_CAG_NUMBER:
			elems->cag_number = pos;
			elems->cag_number_len = elen;
			break;
		case WLAN_EID_AP_CSN:
			if (elen < 1)
				break;
			elems->ap_csn = pos;
			break;
		case WLAN_EID_FILS_INDICATION:
			if (elen < 2)
				break;
			elems->fils_indic = pos;
			elems->fils_indic_len = elen;
			break;
		case WLAN_EID_DILS:
			if (elen < 2)
				break;
			elems->dils = pos;
			elems->dils_len = elen;
			break;
		case WLAN_EID_S1G_CAPABILITIES:
			if (elen < 15)
				break;
			elems->s1g_capab = pos;
			break;
		case WLAN_EID_FRAGMENT:
			wpa_printf(MSG_MSGDUMP,
				   "Fragment without a valid last element - skip");

			break;
		case WLAN_EID_EXTENSION:
			if (ieee802_11_parse_extension(pos, elen, elems, start,
						       len, show_errors))
				unknown++;
			break;
		default:
			unknown++;
			if (!show_errors)
				break;
			wpa_printf(MSG_MSGDUMP, "IEEE 802.11 element parse "
				   "ignored unknown element (id=%d elen=%d)",
				   id, elen);
			break;
		}

		if (elen == 255 && total_len)
			*total_len += ieee802_11_fragments_length(
				elems, pos + elen,
				(start + len) - (pos + elen));

	}

	if (!for_each_element_completed(elem, start, len)) {
		if (show_errors) {
			wpa_printf(MSG_DEBUG,
				   "IEEE 802.11 element parse failed @%d",
				   (int) (start + len - (const u8 *) elem));
			wpa_hexdump(MSG_MSGDUMP, "IEs", start, len);
		}
		return ParseFailed;
	}

done:
	return unknown ? ParseUnknown : ParseOK;
}


/**
 * ieee802_11_parse_elems - Parse information elements in management frames
 * @start: Pointer to the start of IEs
 * @len: Length of IE buffer in octets
 * @elems: Data structure for parsed elements
 * @show_errors: Whether to show parsing errors in debug log
 * Returns: Parsing result
 */
ParseRes ieee802_11_parse_elems(const u8 *start, size_t len,
				struct ieee802_11_elems *elems,
				int show_errors)
{
	os_memset(elems, 0, sizeof(*elems));

	return __ieee802_11_parse_elems(start, len, elems, show_errors);
}


ParseRes ieee802_11_parse_elems_ctrl(const u8 *start, size_t len,
				     struct ieee802_11_elems *elems)
{
	return __ieee802_11_parse_elems(start, len, elems, elems->show_errors);
}


/**
 * ieee802_11_elems_clear_ids - Clear the data for the given element IDs
 * @ids: Array of element IDs for which data should be cleared.
 * @num: The number of entries in the array
 */
void ieee802_11_elems_clear_ids(struct ieee802_11_elems *elems,
				const u8 *ids, size_t num)
{
	size_t i;

	for (i = 0; i < num; i++) {
		switch (ids[i]) {
		case WLAN_EID_SSID:
			elems->ssid = NULL;
			elems->ssid_len = 0;
			break;
		case WLAN_EID_SUPP_RATES:
			elems->supp_rates = NULL;
			elems->supp_rates_len = 0;
			break;
		case WLAN_EID_DS_PARAMS:
			elems->ds_params = NULL;
			break;
		case WLAN_EID_CHALLENGE:
			elems->challenge = NULL;
			elems->challenge_len = 0;
			break;
		case WLAN_EID_ERP_INFO:
			elems->erp_info = NULL;
			break;
		case WLAN_EID_EXT_SUPP_RATES:
			elems->ext_supp_rates = NULL;
			elems->ext_supp_rates_len = 0;
			break;
		case WLAN_EID_RSN:
			elems->rsn_ie = NULL;
			elems->rsn_ie_len = 0;
			break;
		case WLAN_EID_RSNX:
			elems->rsnxe = NULL;
			elems->rsnxe_len = 0;
			break;
		case WLAN_EID_PWR_CAPABILITY:
			elems->power_capab = NULL;
			elems->power_capab_len = 0;
			break;
		case WLAN_EID_SUPPORTED_CHANNELS:
			elems->supp_channels = NULL;
			elems->supp_channels_len = 0;
			break;
		case WLAN_EID_MOBILITY_DOMAIN:
			elems->mdie = NULL;
			elems->mdie_len = 0;
			break;
		case WLAN_EID_FAST_BSS_TRANSITION:
			elems->ftie = NULL;
			elems->ftie_len = 0;
			break;
		case WLAN_EID_TIMEOUT_INTERVAL:
			elems->timeout_int = NULL;
			break;
		case WLAN_EID_HT_CAP:
			elems->ht_capabilities = NULL;
			break;
		case WLAN_EID_HT_OPERATION:
			elems->ht_operation = NULL;
			break;
		case WLAN_EID_MESH_CONFIG:
			elems->mesh_config = NULL;
			elems->mesh_config_len = 0;
			break;
		case WLAN_EID_MESH_ID:
			elems->mesh_id = NULL;
			elems->mesh_id_len = 0;
			break;
		case WLAN_EID_PEER_MGMT:
			elems->peer_mgmt = NULL;
			elems->peer_mgmt_len = 0;
			break;
		case WLAN_EID_VHT_CAP:
			elems->vht_capabilities = NULL;
			break;
		case WLAN_EID_VHT_OPERATION:
			elems->vht_operation = NULL;
			break;
		case WLAN_EID_OPERATING_MODE_NOTIFICATION:
			elems->opmode_notif = NULL;
			break;
		case WLAN_EID_LINK_ID:
			elems->link_id = NULL;
			break;
		case WLAN_EID_INTERWORKING:
			elems->interworking = NULL;
			elems->interworking_len = 0;
			break;
		case WLAN_EID_QOS_MAP_SET:
			elems->qos_map_set = NULL;
			elems->qos_map_set_len = 0;
			break;
		case WLAN_EID_EXT_CAPAB:
			elems->ext_capab = NULL;
			elems->ext_capab_len = 0;
			break;
		case WLAN_EID_BSS_MAX_IDLE_PERIOD:
			elems->bss_max_idle_period = NULL;
			break;
		case WLAN_EID_SSID_LIST:
			elems->ssid_list = NULL;
			elems->ssid_list_len = 0;
			break;
		case WLAN_EID_AMPE:
			elems->ampe = NULL;
			elems->ampe_len = 0;
			break;
		case WLAN_EID_MIC:
			elems->mic = NULL;
			elems->mic_len = 0;
			break;
		case WLAN_EID_MULTI_BAND:
			os_memset(&elems->mb_ies, 0, sizeof(elems->mb_ies));
			elems->mb_ies.nof_ies = 0;
			break;
		case WLAN_EID_SUPPORTED_OPERATING_CLASSES:
			elems->supp_op_classes = NULL;
			elems->supp_op_classes_len = 0;
			break;
		case WLAN_EID_RRM_ENABLED_CAPABILITIES:
			elems->rrm_enabled = NULL;
			elems->rrm_enabled_len = 0;
			break;
		case WLAN_EID_CAG_NUMBER:
			elems->cag_number = NULL;
			elems->cag_number_len = 0;
			break;
		case WLAN_EID_AP_CSN:
			elems->ap_csn = NULL;
			break;
		case WLAN_EID_FILS_INDICATION:
			elems->fils_indic = NULL;
			elems->fils_indic_len = 0;
			break;
		case WLAN_EID_DILS:
			elems->dils = NULL;
			elems->dils_len = 0;
			break;
		case WLAN_EID_S1G_CAPABILITIES:
			elems->s1g_capab = NULL;
			break;
		}
	}
}


/**
 * ieee802_11_elems_clear_ext_ids - Clear the data for the given element
 * extension IDs
 * @ids: Array of element extension IDs for which data should be cleared.
 * @num: The number of entries in the array
 */
void ieee802_11_elems_clear_ext_ids(struct ieee802_11_elems *elems,
				    const u8 *ids, size_t num)
{
	size_t i;

	for (i = 0; i < num; i++) {
		switch (ids[i]) {
		case WLAN_EID_EXT_ASSOC_DELAY_INFO:
			elems->assoc_delay_info = NULL;
			break;
		case WLAN_EID_EXT_FILS_REQ_PARAMS:
			elems->fils_req_params = NULL;
			elems->fils_req_params_len = 0;
			break;
		case WLAN_EID_EXT_FILS_KEY_CONFIRM:
			elems->fils_key_confirm = NULL;
			elems->fils_key_confirm_len = 0;
			break;
		case WLAN_EID_EXT_FILS_SESSION:
			elems->fils_session = NULL;
			break;
		case WLAN_EID_EXT_FILS_HLP_CONTAINER:
			elems->fils_hlp = NULL;
			elems->fils_hlp_len = 0;
			break;
		case WLAN_EID_EXT_FILS_IP_ADDR_ASSIGN:
			elems->fils_ip_addr_assign = NULL;
			elems->fils_ip_addr_assign_len = 0;
			break;
		case WLAN_EID_EXT_KEY_DELIVERY:
			elems->key_delivery = NULL;
			elems->key_delivery_len = 0;
			break;
		case WLAN_EID_EXT_WRAPPED_DATA:
			elems->wrapped_data = NULL;
			elems->wrapped_data_len = 0;
			break;
		case WLAN_EID_EXT_FILS_PUBLIC_KEY:
			elems->fils_pk = NULL;
			elems->fils_pk_len = 0;
			break;
		case WLAN_EID_EXT_NONCE:
			elems->nonce = NULL;
			break;
		case WLAN_EID_EXT_OWE_DH_PARAM:
			elems->owe_dh = NULL;
			elems->owe_dh_len = 0;
			break;
		case WLAN_EID_EXT_PASSWORD_IDENTIFIER:
			elems->password_id = NULL;
			elems->password_id_len = 0;
			break;
		case WLAN_EID_EXT_HE_CAPABILITIES:
			elems->he_capabilities = NULL;
			elems->he_capabilities_len = 0;
			break;
		case WLAN_EID_EXT_HE_OPERATION:
			elems->he_operation = NULL;
			elems->he_operation_len = 0;
			break;
		case WLAN_EID_EXT_OCV_OCI:
			elems->oci = NULL;
			elems->oci_len = 0;
			break;
		case WLAN_EID_EXT_SHORT_SSID_LIST:
			elems->short_ssid_list = NULL;
			elems->short_ssid_list_len = 0;
			break;
		case WLAN_EID_EXT_HE_6GHZ_BAND_CAP:
			elems->he_6ghz_band_cap = NULL;
			break;
		case WLAN_EID_EXT_PASN_PARAMS:
			elems->pasn_params = NULL;
			elems->pasn_params_len = 0;
			break;
		case WLAN_EID_EXT_MULTI_LINK:
			elems->basic_mle = NULL;
			elems->probe_req_mle = NULL;
			elems->reconf_mle = NULL;
			elems->tdls_mle = NULL;
			elems->prior_access_mle = NULL;

			elems->basic_mle_len = 0;
			elems->probe_req_mle_len = 0;
			elems->reconf_mle_len = 0;
			elems->tdls_mle_len = 0;
			elems->prior_access_mle_len = 0;
			break;
		case WLAN_EID_EXT_EHT_CAPABILITIES:
			elems->eht_capabilities = NULL;
			elems->eht_capabilities_len = 0;
			break;
		case WLAN_EID_EXT_EHT_OPERATION:
			elems->eht_operation = NULL;
			elems->eht_operation_len = 0;
			break;
		}
	}
}


static ParseRes ieee802_11_parse_link_profile(struct ieee802_11_elems *elems,
					      struct wpabuf *mlbuf,
					      u8 link_id, bool show_errors,
					      bool is_assoc_resp)
{
	const struct ieee80211_eht_ml *ml;
	const u8 *pos;
	ParseRes res = ParseFailed;
	size_t len;

	pos = wpabuf_head(mlbuf);
	len = wpabuf_len(mlbuf);

	/* Must have control and common info length */
	if (len < sizeof(*ml) + 1 || len < sizeof(*ml) + pos[sizeof(*ml)])
		goto out;

	ml = (const struct ieee80211_eht_ml *) pos;

	/* As we are interested with the Per-STA profile, ignore other types */
	if ((le_to_host16(ml->ml_control) & MULTI_LINK_CONTROL_TYPE_MASK) !=
	     MULTI_LINK_CONTROL_TYPE_BASIC)
		goto out;

	/* Skip the common info */
	len -= sizeof(*ml) + pos[sizeof(*ml)];
	pos += sizeof(*ml) + pos[sizeof(*ml)];

	while (len > 2) {
		size_t sub_elem_len, sta_info_len;
		u16 link_info_control;
		const u8 *non_inherit;
		int num_frag_subelems;

		num_frag_subelems =
			ieee802_11_defrag_mle_subelem(mlbuf, pos,
						      &sub_elem_len);
		if (num_frag_subelems < 0) {
			wpa_printf(MSG_DEBUG,
				   "MLD: Failed to parse MLE subelem");
			goto out;
		}
		if ((size_t) num_frag_subelems * 2 > len)
			goto out;
		len -= num_frag_subelems * 2;

		wpa_printf(MSG_DEBUG,
			   "MLD: sub element: len=%zu, sub_elem_len=%zu, Fragment subelems=%u",
			   len, sub_elem_len, num_frag_subelems);

		if (2 + sub_elem_len > len) {
			if (show_errors)
				wpa_printf(MSG_DEBUG,
					   "MLD: error: len=%zu, sub_elem_len=%zu",
					   len, sub_elem_len);
			goto out;
		}

		if (*pos != 0) {
			pos += 2 + sub_elem_len;
			len -= 2 + sub_elem_len;
			continue;
		}

		if (sub_elem_len < 5) {
			if (show_errors)
				wpa_printf(MSG_DEBUG,
					   "MLD: error: sub_elem_len=%zu < 5",
					   sub_elem_len);
			goto out;
		}

		link_info_control = WPA_GET_LE16(pos + 2);
		if ((link_info_control & BASIC_MLE_STA_CTRL_LINK_ID_MASK) !=
		    link_id) {
			pos += 2 + sub_elem_len;
			len -= 2 + sub_elem_len;
			continue;
		}

		sta_info_len = *(pos + 4);
		if (sub_elem_len < sta_info_len + 3 || sta_info_len < 1) {
			if (show_errors)
				wpa_printf(MSG_DEBUG,
					   "MLD: error: sub_elem_len=%zu, sta_info_len=%zu",
					   sub_elem_len, sta_info_len);
			goto out;
		}

		pos += sta_info_len + 4;
		sub_elem_len -= sta_info_len + 2;

		if (sub_elem_len < 2) {
			if (show_errors)
				wpa_printf(MSG_DEBUG,
					   "MLD: missing capability info");
			goto out;
		}

		pos += 2;
		sub_elem_len -= 2;

		/* For association response, check status code */
		if (is_assoc_resp) {
			u16 status_code;

			if (sub_elem_len < 2) {
				if (show_errors)
					wpa_printf(MSG_DEBUG,
						   "MLD: missing status code");
				goto out;
			}

			status_code = WPA_GET_LE16(pos);
			if (status_code != WLAN_STATUS_SUCCESS) {
				wpa_printf(MSG_DEBUG,
					   "MLD: status code %u", status_code);
				goto out;
			}

			pos += 2;
			sub_elem_len -= 2;
		}

		/* Handle non-inheritance */
		non_inherit = get_ie_ext(pos, sub_elem_len,
					 WLAN_EID_EXT_NON_INHERITANCE);
		if (non_inherit && non_inherit[1] > 1) {
			u8 non_inherit_len = non_inherit[1] - 1;

			/*
			 * Do not include the Non-Inheritance element when
			 * parsing below. It should be the last element in the
			 * subelement.
			 */
			if (3U + non_inherit_len > sub_elem_len)
				goto out;
			sub_elem_len -= 3 + non_inherit_len;

			/* Skip the ID, length and extension ID */
			non_inherit += 3;

			if (non_inherit_len < 1UL + non_inherit[0]) {
				if (show_errors)
					wpa_printf(MSG_DEBUG,
						   "MLD: Invalid inheritance");
				goto out;
			}

			ieee802_11_elems_clear_ids(elems, &non_inherit[1],
						   non_inherit[0]);

			non_inherit_len -= 1 + non_inherit[0];
			non_inherit += 1 + non_inherit[0];

			if (non_inherit_len < 1UL ||
			    non_inherit_len < 1UL + non_inherit[0]) {
				if (show_errors)
					wpa_printf(MSG_DEBUG,
						   "MLD: Invalid inheritance");
				goto out;
			}

			ieee802_11_elems_clear_ext_ids(elems, &non_inherit[1],
						       non_inherit[0]);
		}

		wpa_printf(MSG_DEBUG, "MLD: link: sub_elem_len=%zu",
			   sub_elem_len);

		if (sub_elem_len)
			res = __ieee802_11_parse_elems(pos, sub_elem_len,
						       elems, show_errors);
		else
			res = ParseOK;
		break;
	}

out:
	return res;
}


ParseRes ieee802_11_parse_link_assoc_req(struct ieee802_11_elems *elems,
					 struct wpabuf *mlbuf,
					 u8 link_id, bool show_errors)
{
	return ieee802_11_parse_link_profile(elems, mlbuf, link_id,
					     show_errors, false);
}


ParseRes ieee802_11_parse_link_assoc_resp(struct ieee802_11_elems *elems,
				  struct wpabuf *mlbuf,
					  u8 link_id, bool show_errors)
{
	/* ieee802_11_defrag_mle_subelem() handles subelement defragmentation
	 * in-place within mlbuf */
	return ieee802_11_parse_link_profile(elems, mlbuf, link_id,
					     show_errors, true);
}


int ieee802_11_ie_count(const u8 *ies, size_t ies_len)
{
	const struct element *elem;
	int count = 0;

	if (ies == NULL)
		return 0;

	for_each_element(elem, ies, ies_len)
		count++;

	return count;
}


struct wpabuf * ieee802_11_vendor_ie_concat(const u8 *ies, size_t ies_len,
					    u32 oui_type)
{
	struct wpabuf *buf;
	const struct element *elem, *found = NULL;

	for_each_element_id(elem, WLAN_EID_VENDOR_SPECIFIC, ies, ies_len) {
		if (elem->datalen >= 4 &&
		    WPA_GET_BE32(elem->data) == oui_type) {
			found = elem;
			break;
		}
	}

	if (!found)
		return NULL; /* No specified vendor IE found */

	buf = wpabuf_alloc(ies_len);
	if (buf == NULL)
		return NULL;

	/*
	 * There may be multiple vendor IEs in the message, so need to
	 * concatenate their data fields.
	 */
	for_each_element_id(elem, WLAN_EID_VENDOR_SPECIFIC, ies, ies_len) {
		if (elem->datalen >= 4 && WPA_GET_BE32(elem->data) == oui_type)
			wpabuf_put_data(buf, elem->data + 4, elem->datalen - 4);
	}

	return buf;
}


const u8 * get_hdr_bssid(const struct ieee80211_hdr *hdr, size_t len)
{
	u16 fc, type, stype;

	/*
	 * PS-Poll frames are 16 bytes. All other frames are
	 * 24 bytes or longer.
	 */
	if (len < 16)
		return NULL;

	fc = le_to_host16(hdr->frame_control);
	type = WLAN_FC_GET_TYPE(fc);
	stype = WLAN_FC_GET_STYPE(fc);

	switch (type) {
	case WLAN_FC_TYPE_DATA:
		if (len < 24)
			return NULL;
		switch (fc & (WLAN_FC_FROMDS | WLAN_FC_TODS)) {
		case WLAN_FC_FROMDS | WLAN_FC_TODS:
		case WLAN_FC_TODS:
			return hdr->addr1;
		case WLAN_FC_FROMDS:
			return hdr->addr2;
		default:
			return NULL;
		}
	case WLAN_FC_TYPE_CTRL:
		if (stype != WLAN_FC_STYPE_PSPOLL)
			return NULL;
		return hdr->addr1;
	case WLAN_FC_TYPE_MGMT:
		return hdr->addr3;
	default:
		return NULL;
	}
}


int hostapd_config_wmm_ac(struct hostapd_wmm_ac_params wmm_ac_params[],
			  const char *name, const char *val)
{
	int num, v;
	const char *pos;
	struct hostapd_wmm_ac_params *ac;

	/* skip 'wme_ac_' or 'wmm_ac_' prefix */
	pos = name + 7;
	if (os_strncmp(pos, "be_", 3) == 0) {
		num = 0;
		pos += 3;
	} else if (os_strncmp(pos, "bk_", 3) == 0) {
		num = 1;
		pos += 3;
	} else if (os_strncmp(pos, "vi_", 3) == 0) {
		num = 2;
		pos += 3;
	} else if (os_strncmp(pos, "vo_", 3) == 0) {
		num = 3;
		pos += 3;
	} else {
		wpa_printf(MSG_ERROR, "Unknown WMM name '%s'", pos);
		return -1;
	}

	ac = &wmm_ac_params[num];

	if (os_strcmp(pos, "aifs") == 0) {
		v = atoi(val);
		if (v < 1 || v > 255) {
			wpa_printf(MSG_ERROR, "Invalid AIFS value %d", v);
			return -1;
		}
		ac->aifs = v;
	} else if (os_strcmp(pos, "cwmin") == 0) {
		v = atoi(val);
		if (v < 0 || v > 15) {
			wpa_printf(MSG_ERROR, "Invalid cwMin value %d", v);
			return -1;
		}
		ac->cwmin = v;
	} else if (os_strcmp(pos, "cwmax") == 0) {
		v = atoi(val);
		if (v < 0 || v > 15) {
			wpa_printf(MSG_ERROR, "Invalid cwMax value %d", v);
			return -1;
		}
		ac->cwmax = v;
	} else if (os_strcmp(pos, "txop_limit") == 0) {
		v = atoi(val);
		if (v < 0 || v > 0xffff) {
			wpa_printf(MSG_ERROR, "Invalid txop value %d", v);
			return -1;
		}
		ac->txop_limit = v;
	} else if (os_strcmp(pos, "acm") == 0) {
		v = atoi(val);
		if (v < 0 || v > 1) {
			wpa_printf(MSG_ERROR, "Invalid acm value %d", v);
			return -1;
		}
		ac->admission_control_mandatory = v;
	} else {
		wpa_printf(MSG_ERROR, "Unknown wmm_ac_ field '%s'", pos);
		return -1;
	}

	return 0;
}


/* convert floats with one decimal place to value*10 int, i.e.,
 * "1.5" will return 15
 */
static int hostapd_config_read_int10(const char *value)
{
	int i, d;
	char *pos;

	i = atoi(value);
	pos = os_strchr(value, '.');
	d = 0;
	if (pos) {
		pos++;
		if (*pos >= '0' && *pos <= '9')
			d = *pos - '0';
	}

	return i * 10 + d;
}


static int valid_cw(int cw)
{
	return (cw == 1 || cw == 3 || cw == 7 || cw == 15 || cw == 31 ||
		cw == 63 || cw == 127 || cw == 255 || cw == 511 || cw == 1023 ||
		cw == 2047 || cw == 4095 || cw == 8191 || cw == 16383 ||
		cw == 32767);
}


int hostapd_config_tx_queue(struct hostapd_tx_queue_params tx_queue[],
			    const char *name, const char *val)
{
	int num;
	const char *pos;
	struct hostapd_tx_queue_params *queue;

	/* skip 'tx_queue_' prefix */
	pos = name + 9;
	if (os_strncmp(pos, "data", 4) == 0 &&
	    pos[4] >= '0' && pos[4] <= '9' && pos[5] == '_') {
		num = pos[4] - '0';
		pos += 6;
	} else if (os_strncmp(pos, "after_beacon_", 13) == 0 ||
		   os_strncmp(pos, "beacon_", 7) == 0) {
		wpa_printf(MSG_INFO, "DEPRECATED: '%s' not used", name);
		return 0;
	} else {
		wpa_printf(MSG_ERROR, "Unknown tx_queue name '%s'", pos);
		return -1;
	}

	if (num >= NUM_TX_QUEUES) {
		/* for backwards compatibility, do not trigger failure */
		wpa_printf(MSG_INFO, "DEPRECATED: '%s' not used", name);
		return 0;
	}

	queue = &tx_queue[num];

	if (os_strcmp(pos, "aifs") == 0) {
		queue->aifs = atoi(val);
		if (queue->aifs < 0 || queue->aifs > 255) {
			wpa_printf(MSG_ERROR, "Invalid AIFS value %d",
				   queue->aifs);
			return -1;
		}
	} else if (os_strcmp(pos, "cwmin") == 0) {
		queue->cwmin = atoi(val);
		if (!valid_cw(queue->cwmin)) {
			wpa_printf(MSG_ERROR, "Invalid cwMin value %d",
				   queue->cwmin);
			return -1;
		}
	} else if (os_strcmp(pos, "cwmax") == 0) {
		queue->cwmax = atoi(val);
		if (!valid_cw(queue->cwmax)) {
			wpa_printf(MSG_ERROR, "Invalid cwMax value %d",
				   queue->cwmax);
			return -1;
		}
	} else if (os_strcmp(pos, "burst") == 0) {
		queue->burst = hostapd_config_read_int10(val);
	} else {
		wpa_printf(MSG_ERROR, "Unknown queue field '%s'", pos);
		return -1;
	}

	return 0;
}


enum hostapd_hw_mode ieee80211_freq_to_chan(int freq, u8 *channel)
{
	u8 op_class;

	return ieee80211_freq_to_channel_ext(freq, 0, CONF_OPER_CHWIDTH_USE_HT,
					     &op_class, channel);
}


/**
 * ieee80211_freq_to_channel_ext - Convert frequency into channel info
 * for HT40, VHT, and HE. DFS channels are not covered.
 * @freq: Frequency (MHz) to convert
 * @sec_channel: 0 = non-HT40, 1 = sec. channel above, -1 = sec. channel below
 * @chanwidth: VHT/EDMG/etc. channel width
 * @op_class: Buffer for returning operating class
 * @channel: Buffer for returning channel number
 * Returns: hw_mode on success, NUM_HOSTAPD_MODES on failure
 */
enum hostapd_hw_mode
ieee80211_freq_to_channel_ext(unsigned int freq, int sec_channel,
			      enum oper_chan_width chanwidth,
			      u8 *op_class, u8 *channel)
{
	u8 vht_opclass;

	/* TODO: more operating classes */

	if (sec_channel > 1 || sec_channel < -1)
		return NUM_HOSTAPD_MODES;

	if (freq >= 2412 && freq <= 2472) {
		if ((freq - 2407) % 5)
			return NUM_HOSTAPD_MODES;

		if (chanwidth)
			return NUM_HOSTAPD_MODES;

		/* 2.407 GHz, channels 1..13 */
		if (sec_channel == 1)
			*op_class = 83;
		else if (sec_channel == -1)
			*op_class = 84;
		else
			*op_class = 81;

		*channel = (freq - 2407) / 5;

		return HOSTAPD_MODE_IEEE80211G;
	}

	if (freq == 2484) {
		if (sec_channel || chanwidth)
			return NUM_HOSTAPD_MODES;

		*op_class = 82; /* channel 14 */
		*channel = 14;

		return HOSTAPD_MODE_IEEE80211B;
	}

	if (freq >= 4900 && freq < 5000) {
		if ((freq - 4000) % 5)
			return NUM_HOSTAPD_MODES;
		*channel = (freq - 4000) / 5;
		*op_class = 0; /* TODO */
		return HOSTAPD_MODE_IEEE80211A;
	}

	switch (chanwidth) {
	case CONF_OPER_CHWIDTH_80MHZ:
		vht_opclass = 128;
		break;
	case CONF_OPER_CHWIDTH_160MHZ:
		vht_opclass = 129;
		break;
	case CONF_OPER_CHWIDTH_80P80MHZ:
		vht_opclass = 130;
		break;
	default:
		vht_opclass = 0;
		break;
	}

	/* 5 GHz, channels 36..48 */
	if (freq >= 5180 && freq <= 5240) {
		if ((freq - 5000) % 5)
			return NUM_HOSTAPD_MODES;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 116;
		else if (sec_channel == -1)
			*op_class = 117;
		else
			*op_class = 115;

		*channel = (freq - 5000) / 5;

		return HOSTAPD_MODE_IEEE80211A;
	}

	/* 5 GHz, channels 52..64 */
	if (freq >= 5260 && freq <= 5320) {
		if ((freq - 5000) % 5)
			return NUM_HOSTAPD_MODES;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 119;
		else if (sec_channel == -1)
			*op_class = 120;
		else
			*op_class = 118;

		*channel = (freq - 5000) / 5;

		return HOSTAPD_MODE_IEEE80211A;
	}

	/* 5 GHz, channels 149..177 */
	if (freq >= 5745 && freq <= 5885) {
		if ((freq - 5000) % 5)
			return NUM_HOSTAPD_MODES;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 126;
		else if (sec_channel == -1)
			*op_class = 127;
		else
			*op_class = 125;

		*channel = (freq - 5000) / 5;

		return HOSTAPD_MODE_IEEE80211A;
	}

	/* 5 GHz, channels 100..144 */
	if (freq >= 5500 && freq <= 5720) {
		if ((freq - 5000) % 5)
			return NUM_HOSTAPD_MODES;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 122;
		else if (sec_channel == -1)
			*op_class = 123;
		else
			*op_class = 121;

		*channel = (freq - 5000) / 5;

		return HOSTAPD_MODE_IEEE80211A;
	}

	if (freq >= 5000 && freq < 5900) {
		if ((freq - 5000) % 5)
			return NUM_HOSTAPD_MODES;
		*channel = (freq - 5000) / 5;
		if (vht_opclass)
			*op_class = vht_opclass;
		else
			*op_class = 0;

		return HOSTAPD_MODE_IEEE80211A;
	}

	if (freq > 5950 && freq <= 7115) {
		if ((freq - 5950) % 5)
			return NUM_HOSTAPD_MODES;

		switch (chanwidth) {
		case CONF_OPER_CHWIDTH_80MHZ:
			*op_class = 133;
			break;
		case CONF_OPER_CHWIDTH_160MHZ:
			*op_class = 134;
			break;
		case CONF_OPER_CHWIDTH_80P80MHZ:
			*op_class = 135;
			break;
		case CONF_OPER_CHWIDTH_320MHZ:
			*op_class = 137;
			break;
		default:
			if (sec_channel)
				*op_class = 132;
			else
				*op_class = 131;
			break;
		}

		*channel = (freq - 5950) / 5;
		return HOSTAPD_MODE_IEEE80211A;
	}

	if (freq == 5935) {
		*op_class = 136;
		*channel = (freq - 5925) / 5;
		return HOSTAPD_MODE_IEEE80211A;
	}

	/* 56.16 GHz, channel 1..6 */
	if (freq >= 56160 + 2160 * 1 && freq <= 56160 + 2160 * 6) {
		if (sec_channel)
			return NUM_HOSTAPD_MODES;

		switch (chanwidth) {
		case CONF_OPER_CHWIDTH_USE_HT:
		case CONF_OPER_CHWIDTH_2160MHZ:
			*channel = (freq - 56160) / 2160;
			*op_class = 180;
			break;
		case CONF_OPER_CHWIDTH_4320MHZ:
			/* EDMG channels 9 - 13 */
			if (freq > 56160 + 2160 * 5)
				return NUM_HOSTAPD_MODES;

			*channel = (freq - 56160) / 2160 + 8;
			*op_class = 181;
			break;
		case CONF_OPER_CHWIDTH_6480MHZ:
			/* EDMG channels 17 - 20 */
			if (freq > 56160 + 2160 * 4)
				return NUM_HOSTAPD_MODES;

			*channel = (freq - 56160) / 2160 + 16;
			*op_class = 182;
			break;
		case CONF_OPER_CHWIDTH_8640MHZ:
			/* EDMG channels 25 - 27 */
			if (freq > 56160 + 2160 * 3)
				return NUM_HOSTAPD_MODES;

			*channel = (freq - 56160) / 2160 + 24;
			*op_class = 183;
			break;
		default:
			return NUM_HOSTAPD_MODES;
		}

		return HOSTAPD_MODE_IEEE80211AD;
	}

	return NUM_HOSTAPD_MODES;
}


int ieee80211_chaninfo_to_channel(unsigned int freq, enum chan_width chanwidth,
				  int sec_channel, u8 *op_class, u8 *channel)
{
	int cw = CHAN_WIDTH_UNKNOWN;

	switch (chanwidth) {
	case CHAN_WIDTH_UNKNOWN:
	case CHAN_WIDTH_20_NOHT:
	case CHAN_WIDTH_20:
	case CHAN_WIDTH_40:
		cw = CONF_OPER_CHWIDTH_USE_HT;
		break;
	case CHAN_WIDTH_80:
		cw = CONF_OPER_CHWIDTH_80MHZ;
		break;
	case CHAN_WIDTH_80P80:
		cw = CONF_OPER_CHWIDTH_80P80MHZ;
		break;
	case CHAN_WIDTH_160:
		cw = CONF_OPER_CHWIDTH_160MHZ;
		break;
	case CHAN_WIDTH_2160:
		cw = CONF_OPER_CHWIDTH_2160MHZ;
		break;
	case CHAN_WIDTH_4320:
		cw = CONF_OPER_CHWIDTH_4320MHZ;
		break;
	case CHAN_WIDTH_6480:
		cw = CONF_OPER_CHWIDTH_6480MHZ;
		break;
	case CHAN_WIDTH_8640:
		cw = CONF_OPER_CHWIDTH_8640MHZ;
		break;
	case CHAN_WIDTH_320:
		cw = CONF_OPER_CHWIDTH_320MHZ;
		break;
	}

	if (ieee80211_freq_to_channel_ext(freq, sec_channel, cw, op_class,
					  channel) == NUM_HOSTAPD_MODES) {
		wpa_printf(MSG_WARNING,
			   "Cannot determine operating class and channel (freq=%u chanwidth=%d sec_channel=%d)",
			   freq, chanwidth, sec_channel);
		return -1;
	}

	return 0;
}


static const char *const us_op_class_cc[] = {
	"US", "CA", NULL
};

static const char *const eu_op_class_cc[] = {
	"AL", "AM", "AT", "AZ", "BA", "BE", "BG", "BY", "CH", "CY", "CZ", "DE",
	"DK", "EE", "EL", "ES", "FI", "FR", "GE", "HR", "HU", "IE", "IS", "IT",
	"LI", "LT", "LU", "LV", "MD", "ME", "MK", "MT", "NL", "NO", "PL", "PT",
	"RO", "RS", "RU", "SE", "SI", "SK", "TR", "UA", "UK", NULL
};

static const char *const jp_op_class_cc[] = {
	"JP", NULL
};

static const char *const cn_op_class_cc[] = {
	"CN", NULL
};


static int country_match(const char *const cc[], const char *const country)
{
	int i;

	if (country == NULL)
		return 0;
	for (i = 0; cc[i]; i++) {
		if (cc[i][0] == country[0] && cc[i][1] == country[1])
			return 1;
	}

	return 0;
}


static int ieee80211_chan_to_freq_us(u8 op_class, u8 chan)
{
	switch (op_class) {
	case 12: /* channels 1..11 */
	case 32: /* channels 1..7; 40 MHz */
	case 33: /* channels 5..11; 40 MHz */
		if (chan < 1 || chan > 11)
			return -1;
		return 2407 + 5 * chan;
	case 1: /* channels 36,40,44,48 */
	case 2: /* channels 52,56,60,64; dfs */
	case 22: /* channels 36,44; 40 MHz */
	case 23: /* channels 52,60; 40 MHz */
	case 27: /* channels 40,48; 40 MHz */
	case 28: /* channels 56,64; 40 MHz */
		if (chan < 36 || chan > 64)
			return -1;
		return 5000 + 5 * chan;
	case 4: /* channels 100-144 */
	case 24: /* channels 100-140; 40 MHz */
		if (chan < 100 || chan > 144)
			return -1;
		return 5000 + 5 * chan;
	case 3: /* channels 149,153,157,161 */
	case 25: /* channels 149,157; 40 MHz */
	case 26: /* channels 149,157; 40 MHz */
	case 30: /* channels 153,161; 40 MHz */
	case 31: /* channels 153,161; 40 MHz */
		if (chan < 149 || chan > 161)
			return -1;
		return 5000 + 5 * chan;
	case 5: /* channels 149,153,157,161,165 */
		if (chan < 149 || chan > 165)
			return -1;
		return 5000 + 5 * chan;
	case 34: /* 60 GHz band, channels 1..8 */
		if (chan < 1 || chan > 8)
			return -1;
		return 56160 + 2160 * chan;
	case 37: /* 60 GHz band, EDMG CB2, channels 9..15 */
		if (chan < 9 || chan > 15)
			return -1;
		return 56160 + 2160 * (chan - 8);
	case 38: /* 60 GHz band, EDMG CB3, channels 17..22 */
		if (chan < 17 || chan > 22)
			return -1;
		return 56160 + 2160 * (chan - 16);
	case 39: /* 60 GHz band, EDMG CB4, channels 25..29 */
		if (chan < 25 || chan > 29)
			return -1;
		return 56160 + 2160 * (chan - 24);
	default:
		return -1;
	}
}


static int ieee80211_chan_to_freq_eu(u8 op_class, u8 chan)
{
	switch (op_class) {
	case 4: /* channels 1..13 */
	case 11: /* channels 1..9; 40 MHz */
	case 12: /* channels 5..13; 40 MHz */
		if (chan < 1 || chan > 13)
			return -1;
		return 2407 + 5 * chan;
	case 1: /* channels 36,40,44,48 */
	case 2: /* channels 52,56,60,64; dfs */
	case 5: /* channels 36,44; 40 MHz */
	case 6: /* channels 52,60; 40 MHz */
	case 8: /* channels 40,48; 40 MHz */
	case 9: /* channels 56,64; 40 MHz */
		if (chan < 36 || chan > 64)
			return -1;
		return 5000 + 5 * chan;
	case 3: /* channels 100-140 */
	case 7: /* channels 100-132; 40 MHz */
	case 10: /* channels 104-136; 40 MHz */
	case 16: /* channels 100-140 */
		if (chan < 100 || chan > 140)
			return -1;
		return 5000 + 5 * chan;
	case 17: /* channels 149,153,157,161,165,169 */
		if (chan < 149 || chan > 169)
			return -1;
		return 5000 + 5 * chan;
	case 18: /* 60 GHz band, channels 1..6 */
		if (chan < 1 || chan > 6)
			return -1;
		return 56160 + 2160 * chan;
	case 21: /* 60 GHz band, EDMG CB2, channels 9..11 */
		if (chan < 9 || chan > 11)
			return -1;
		return 56160 + 2160 * (chan - 8);
	case 22: /* 60 GHz band, EDMG CB3, channels 17..18 */
		if (chan < 17 || chan > 18)
			return -1;
		return 56160 + 2160 * (chan - 16);
	case 23: /* 60 GHz band, EDMG CB4, channels 25 */
		if (chan != 25)
			return -1;
		return 56160 + 2160 * (chan - 24);
	default:
		return -1;
	}
}


static int ieee80211_chan_to_freq_jp(u8 op_class, u8 chan)
{
	/* Table E-3 in IEEE Std 802.11-2020 - Operating classes in Japan */
	switch (op_class) {
	case 30: /* channels 1..13 */
	case 56: /* channels 1..9; 40 MHz */
	case 57: /* channels 5..13; 40 MHz */
		if (chan < 1 || chan > 13)
			return -1;
		return 2407 + 5 * chan;
	case 31: /* channel 14 */
		if (chan != 14)
			return -1;
		return 2414 + 5 * chan;
	case 1: /* channels 34,38,42,46(old) or 36,40,44,48 */
	case 32: /* channels 52,56,60,64 */
	case 33: /* channels 52,56,60,64 */
	case 36: /* channels 36,44; 40 MHz */
	case 37: /* channels 52,60; 40 MHz */
	case 38: /* channels 52,60; 40 MHz */
	case 41: /* channels 40,48; 40 MHz */
	case 42: /* channels 56,64; 40 MHz */
	case 43: /* channels 56,64; 40 MHz */
		if (chan < 34 || chan > 64)
			return -1;
		return 5000 + 5 * chan;
	case 34: /* channels 100-144 */
	case 35: /* reserved */
	case 39: /* channels 100-140; 40 MHz */
	case 40: /* reserved */
	case 44: /* channels 104-144; 40 MHz */
	case 45: /* reserved */
	case 58: /* channels 100-144 */
		if (chan < 100 || chan > 144)
			return -1;
		return 5000 + 5 * chan;
	case 59: /* 60 GHz band, channels 1..6 */
		if (chan < 1 || chan > 6)
			return -1;
		return 56160 + 2160 * chan;
	case 62: /* 60 GHz band, EDMG CB2, channels 9..11 */
		if (chan < 9 || chan > 11)
			return -1;
		return 56160 + 2160 * (chan - 8);
	case 63: /* 60 GHz band, EDMG CB3, channels 17..18 */
		if (chan < 17 || chan > 18)
			return -1;
		return 56160 + 2160 * (chan - 16);
	case 64: /* 60 GHz band, EDMG CB4, channel 25 */
		if (chan != 25)
			return -1;
		return 56160 + 2160 * (chan - 24);
	default:
		return -1;
	}
}


static int ieee80211_chan_to_freq_cn(u8 op_class, u8 chan)
{
	switch (op_class) {
	case 7: /* channels 1..13 */
	case 8: /* channels 1..9; 40 MHz */
	case 9: /* channels 5..13; 40 MHz */
		if (chan < 1 || chan > 13)
			return -1;
		return 2407 + 5 * chan;
	case 1: /* channels 36,40,44,48 */
	case 2: /* channels 52,56,60,64; dfs */
	case 4: /* channels 36,44; 40 MHz */
	case 5: /* channels 52,60; 40 MHz */
		if (chan < 36 || chan > 64)
			return -1;
		return 5000 + 5 * chan;
	case 3: /* channels 149,153,157,161,165 */
	case 6: /* channels 149,157; 40 MHz */
		if (chan < 149 || chan > 165)
			return -1;
		return 5000 + 5 * chan;
	default:
		return -1;
	}
}


static int ieee80211_chan_to_freq_global(u8 op_class, u8 chan)
{
	/* Table E-4 in IEEE Std 802.11-2020 - Global operating classes */
	switch (op_class) {
	case 81:
		/* channels 1..13 */
		if (chan < 1 || chan > 13)
			return -1;
		return 2407 + 5 * chan;
	case 82:
		/* channel 14 */
		if (chan != 14)
			return -1;
		return 2414 + 5 * chan;
	case 83: /* channels 1..9; 40 MHz */
	case 84: /* channels 5..13; 40 MHz */
		if (chan < 1 || chan > 13)
			return -1;
		return 2407 + 5 * chan;
	case 115: /* channels 36,40,44,48; indoor only */
	case 116: /* channels 36,44; 40 MHz; indoor only */
	case 117: /* channels 40,48; 40 MHz; indoor only */
	case 118: /* channels 52,56,60,64; dfs */
	case 119: /* channels 52,60; 40 MHz; dfs */
	case 120: /* channels 56,64; 40 MHz; dfs */
		if (chan < 36 || chan > 64)
			return -1;
		return 5000 + 5 * chan;
	case 121: /* channels 100-144 */
	case 122: /* channels 100-140; 40 MHz */
	case 123: /* channels 104-144; 40 MHz */
		if (chan < 100 || chan > 144)
			return -1;
		return 5000 + 5 * chan;
	case 124: /* channels 149,153,157,161 */
		if (chan < 149 || chan > 161)
			return -1;
		return 5000 + 5 * chan;
	case 125: /* channels 149,153,157,161,165,169,173,177 */
	case 126: /* channels 149,157,165,173; 40 MHz */
	case 127: /* channels 153,161,169,177; 40 MHz */
		if (chan < 149 || chan > 177)
			return -1;
		return 5000 + 5 * chan;
	case 128: /* center freqs 42, 58, 106, 122, 138, 155, 171; 80 MHz */
	case 130: /* center freqs 42, 58, 106, 122, 138, 155, 171; 80 MHz */
		if (chan < 36 || chan > 177)
			return -1;
		return 5000 + 5 * chan;
	case 129: /* center freqs 50, 114, 163; 160 MHz */
		if (chan < 36 || chan > 177)
			return -1;
		return 5000 + 5 * chan;
	case 131: /* UHB channels, 20 MHz: 1, 5, 9.. */
	case 132: /* UHB channels, 40 MHz: 3, 11, 19.. */
	case 133: /* UHB channels, 80 MHz: 7, 23, 39.. */
	case 134: /* UHB channels, 160 MHz: 15, 47, 79.. */
	case 135: /* UHB channels, 80+80 MHz: 7, 23, 39.. */
	case 137: /* UHB channels, 320 MHz: 31, 63, 95, 127, 159, 191 */
		if (chan < 1 || chan > 233)
			return -1;
		return 5950 + chan * 5;
	case 136: /* UHB channels, 20 MHz: 2 */
		if (chan == 2)
			return 5935;
		return -1;
	case 180: /* 60 GHz band, channels 1..8 */
		if (chan < 1 || chan > 8)
			return -1;
		return 56160 + 2160 * chan;
	case 181: /* 60 GHz band, EDMG CB2, channels 9..15 */
		if (chan < 9 || chan > 15)
			return -1;
		return 56160 + 2160 * (chan - 8);
	case 182: /* 60 GHz band, EDMG CB3, channels 17..22 */
		if (chan < 17 || chan > 22)
			return -1;
		return 56160 + 2160 * (chan - 16);
	case 183: /* 60 GHz band, EDMG CB4, channel 25..29 */
		if (chan < 25 || chan > 29)
			return -1;
		return 56160 + 2160 * (chan - 24);
	default:
		return -1;
	}
}

/**
 * ieee80211_chan_to_freq - Convert channel info to frequency
 * @country: Country code, if known; otherwise, global operating class is used
 * @op_class: Operating class
 * @chan: Channel number
 * Returns: Frequency in MHz or -1 if the specified channel is unknown
 */
int ieee80211_chan_to_freq(const char *country, u8 op_class, u8 chan)
{
	int freq;

	if (country_match(us_op_class_cc, country)) {
		freq = ieee80211_chan_to_freq_us(op_class, chan);
		if (freq > 0)
			return freq;
	}

	if (country_match(eu_op_class_cc, country)) {
		freq = ieee80211_chan_to_freq_eu(op_class, chan);
		if (freq > 0)
			return freq;
	}

	if (country_match(jp_op_class_cc, country)) {
		freq = ieee80211_chan_to_freq_jp(op_class, chan);
		if (freq > 0)
			return freq;
	}

	if (country_match(cn_op_class_cc, country)) {
		freq = ieee80211_chan_to_freq_cn(op_class, chan);
		if (freq > 0)
			return freq;
	}

	return ieee80211_chan_to_freq_global(op_class, chan);
}


int ieee80211_is_dfs(int freq, const struct hostapd_hw_modes *modes,
		     u16 num_modes)
{
	int i, j;

	if (!modes || !num_modes)
		return (freq >= 5260 && freq <= 5320) ||
			(freq >= 5500 && freq <= 5720);

	for (i = 0; i < num_modes; i++) {
		for (j = 0; j < modes[i].num_channels; j++) {
			if (modes[i].channels[j].freq == freq &&
			    (modes[i].channels[j].flag & HOSTAPD_CHAN_RADAR))
				return 1;
		}
	}

	return 0;
}


/*
 * 802.11-2020: Table E-4 - Global operating classes
 * DFS_50_100_Behavior: 118, 119, 120, 121, 122, 123
 */
int is_dfs_global_op_class(u8 op_class)
{
    return (op_class >= 118) && (op_class <= 123);
}


bool is_80plus_op_class(u8 op_class)
{
	/* Operating classes with "80+" behavior indication in Table E-4 */
	return op_class == 130 || op_class == 135;
}


static int is_11b(u8 rate)
{
	return rate == 0x02 || rate == 0x04 || rate == 0x0b || rate == 0x16;
}


int supp_rates_11b_only(struct ieee802_11_elems *elems)
{
	int num_11b = 0, num_others = 0;
	int i;

	if (elems->supp_rates == NULL && elems->ext_supp_rates == NULL)
		return 0;

	for (i = 0; elems->supp_rates && i < elems->supp_rates_len; i++) {
		if (is_11b(elems->supp_rates[i]))
			num_11b++;
		else
			num_others++;
	}

	for (i = 0; elems->ext_supp_rates && i < elems->ext_supp_rates_len;
	     i++) {
		if (is_11b(elems->ext_supp_rates[i]))
			num_11b++;
		else
			num_others++;
	}

	return num_11b > 0 && num_others == 0;
}


const char * fc2str(u16 fc)
{
	u16 stype = WLAN_FC_GET_STYPE(fc);
#define C2S(x) case x: return #x;

	switch (WLAN_FC_GET_TYPE(fc)) {
	case WLAN_FC_TYPE_MGMT:
		switch (stype) {
		C2S(WLAN_FC_STYPE_ASSOC_REQ)
		C2S(WLAN_FC_STYPE_ASSOC_RESP)
		C2S(WLAN_FC_STYPE_REASSOC_REQ)
		C2S(WLAN_FC_STYPE_REASSOC_RESP)
		C2S(WLAN_FC_STYPE_PROBE_REQ)
		C2S(WLAN_FC_STYPE_PROBE_RESP)
		C2S(WLAN_FC_STYPE_BEACON)
		C2S(WLAN_FC_STYPE_ATIM)
		C2S(WLAN_FC_STYPE_DISASSOC)
		C2S(WLAN_FC_STYPE_AUTH)
		C2S(WLAN_FC_STYPE_DEAUTH)
		C2S(WLAN_FC_STYPE_ACTION)
		}
		break;
	case WLAN_FC_TYPE_CTRL:
		switch (stype) {
		C2S(WLAN_FC_STYPE_PSPOLL)
		C2S(WLAN_FC_STYPE_RTS)
		C2S(WLAN_FC_STYPE_CTS)
		C2S(WLAN_FC_STYPE_ACK)
		C2S(WLAN_FC_STYPE_CFEND)
		C2S(WLAN_FC_STYPE_CFENDACK)
		}
		break;
	case WLAN_FC_TYPE_DATA:
		switch (stype) {
		C2S(WLAN_FC_STYPE_DATA)
		C2S(WLAN_FC_STYPE_DATA_CFACK)
		C2S(WLAN_FC_STYPE_DATA_CFPOLL)
		C2S(WLAN_FC_STYPE_DATA_CFACKPOLL)
		C2S(WLAN_FC_STYPE_NULLFUNC)
		C2S(WLAN_FC_STYPE_CFACK)
		C2S(WLAN_FC_STYPE_CFPOLL)
		C2S(WLAN_FC_STYPE_CFACKPOLL)
		C2S(WLAN_FC_STYPE_QOS_DATA)
		C2S(WLAN_FC_STYPE_QOS_DATA_CFACK)
		C2S(WLAN_FC_STYPE_QOS_DATA_CFPOLL)
		C2S(WLAN_FC_STYPE_QOS_DATA_CFACKPOLL)
		C2S(WLAN_FC_STYPE_QOS_NULL)
		C2S(WLAN_FC_STYPE_QOS_CFPOLL)
		C2S(WLAN_FC_STYPE_QOS_CFACKPOLL)
		}
		break;
	}
	return "WLAN_FC_TYPE_UNKNOWN";
#undef C2S
}


const char * reason2str(u16 reason)
{
#define R2S(r) case WLAN_REASON_ ## r: return #r;
	switch (reason) {
	R2S(UNSPECIFIED)
	R2S(PREV_AUTH_NOT_VALID)
	R2S(DEAUTH_LEAVING)
	R2S(DISASSOC_DUE_TO_INACTIVITY)
	R2S(DISASSOC_AP_BUSY)
	R2S(CLASS2_FRAME_FROM_NONAUTH_STA)
	R2S(CLASS3_FRAME_FROM_NONASSOC_STA)
	R2S(DISASSOC_STA_HAS_LEFT)
	R2S(STA_REQ_ASSOC_WITHOUT_AUTH)
	R2S(PWR_CAPABILITY_NOT_VALID)
	R2S(SUPPORTED_CHANNEL_NOT_VALID)
	R2S(BSS_TRANSITION_DISASSOC)
	R2S(INVALID_IE)
	R2S(MICHAEL_MIC_FAILURE)
	R2S(4WAY_HANDSHAKE_TIMEOUT)
	R2S(GROUP_KEY_UPDATE_TIMEOUT)
	R2S(IE_IN_4WAY_DIFFERS)
	R2S(GROUP_CIPHER_NOT_VALID)
	R2S(PAIRWISE_CIPHER_NOT_VALID)
	R2S(AKMP_NOT_VALID)
	R2S(UNSUPPORTED_RSN_IE_VERSION)
	R2S(INVALID_RSN_IE_CAPAB)
	R2S(IEEE_802_1X_AUTH_FAILED)
	R2S(CIPHER_SUITE_REJECTED)
	R2S(TDLS_TEARDOWN_UNREACHABLE)
	R2S(TDLS_TEARDOWN_UNSPECIFIED)
	R2S(SSP_REQUESTED_DISASSOC)
	R2S(NO_SSP_ROAMING_AGREEMENT)
	R2S(BAD_CIPHER_OR_AKM)
	R2S(NOT_AUTHORIZED_THIS_LOCATION)
	R2S(SERVICE_CHANGE_PRECLUDES_TS)
	R2S(UNSPECIFIED_QOS_REASON)
	R2S(NOT_ENOUGH_BANDWIDTH)
	R2S(DISASSOC_LOW_ACK)
	R2S(EXCEEDED_TXOP)
	R2S(STA_LEAVING)
	R2S(END_TS_BA_DLS)
	R2S(UNKNOWN_TS_BA)
	R2S(TIMEOUT)
	R2S(PEERKEY_MISMATCH)
	R2S(AUTHORIZED_ACCESS_LIMIT_REACHED)
	R2S(EXTERNAL_SERVICE_REQUIREMENTS)
	R2S(INVALID_FT_ACTION_FRAME_COUNT)
	R2S(INVALID_PMKID)
	R2S(INVALID_MDE)
	R2S(INVALID_FTE)
	R2S(MESH_PEERING_CANCELLED)
	R2S(MESH_MAX_PEERS)
	R2S(MESH_CONFIG_POLICY_VIOLATION)
	R2S(MESH_CLOSE_RCVD)
	R2S(MESH_MAX_RETRIES)
	R2S(MESH_CONFIRM_TIMEOUT)
	R2S(MESH_INVALID_GTK)
	R2S(MESH_INCONSISTENT_PARAMS)
	R2S(MESH_INVALID_SECURITY_CAP)
	R2S(MESH_PATH_ERROR_NO_PROXY_INFO)
	R2S(MESH_PATH_ERROR_NO_FORWARDING_INFO)
	R2S(MESH_PATH_ERROR_DEST_UNREACHABLE)
	R2S(MAC_ADDRESS_ALREADY_EXISTS_IN_MBSS)
	R2S(MESH_CHANNEL_SWITCH_REGULATORY_REQ)
	R2S(MESH_CHANNEL_SWITCH_UNSPECIFIED)
	}
	return "UNKNOWN";
#undef R2S
}


const char * status2str(u16 status)
{
#define S2S(s) case WLAN_STATUS_ ## s: return #s;
	switch (status) {
	S2S(SUCCESS)
	S2S(UNSPECIFIED_FAILURE)
	S2S(TDLS_WAKEUP_ALTERNATE)
	S2S(TDLS_WAKEUP_REJECT)
	S2S(SECURITY_DISABLED)
	S2S(UNACCEPTABLE_LIFETIME)
	S2S(NOT_IN_SAME_BSS)
	S2S(CAPS_UNSUPPORTED)
	S2S(REASSOC_NO_ASSOC)
	S2S(ASSOC_DENIED_UNSPEC)
	S2S(NOT_SUPPORTED_AUTH_ALG)
	S2S(UNKNOWN_AUTH_TRANSACTION)
	S2S(CHALLENGE_FAIL)
	S2S(AUTH_TIMEOUT)
	S2S(AP_UNABLE_TO_HANDLE_NEW_STA)
	S2S(ASSOC_DENIED_RATES)
	S2S(ASSOC_DENIED_NOSHORT)
	S2S(SPEC_MGMT_REQUIRED)
	S2S(PWR_CAPABILITY_NOT_VALID)
	S2S(SUPPORTED_CHANNEL_NOT_VALID)
	S2S(ASSOC_DENIED_NO_SHORT_SLOT_TIME)
	S2S(ASSOC_DENIED_NO_HT)
	S2S(R0KH_UNREACHABLE)
	S2S(ASSOC_DENIED_NO_PCO)
	S2S(ASSOC_REJECTED_TEMPORARILY)
	S2S(ROBUST_MGMT_FRAME_POLICY_VIOLATION)
	S2S(UNSPECIFIED_QOS_FAILURE)
	S2S(DENIED_INSUFFICIENT_BANDWIDTH)
	S2S(DENIED_POOR_CHANNEL_CONDITIONS)
	S2S(DENIED_QOS_NOT_SUPPORTED)
	S2S(REQUEST_DECLINED)
	S2S(INVALID_PARAMETERS)
	S2S(REJECTED_WITH_SUGGESTED_CHANGES)
	S2S(INVALID_ELEMENT)
	S2S(INVALID_GROUP_CIPHER)
	S2S(INVALID_PAIRWISE_CIPHER)
	S2S(INVALID_AKMP)
	S2S(UNSUPPORTED_RSNE_VERSION)
	S2S(INVALID_RSNE_CAPABILITIES)
	S2S(CIPHER_OUT_OF_POLICY)
	S2S(TS_NOT_CREATED)
	S2S(DIRECT_LINK_NOT_ALLOWED)
	S2S(DEST_STA_NOT_PRESENT)
	S2S(DEST_STA_NOT_QOS_STA)
	S2S(ASSOC_DENIED_LISTEN_INT_TOO_LARGE)
	S2S(INVALID_FT_ACTION_FRAME_COUNT)
	S2S(INVALID_PMKID)
	S2S(INVALID_MDE)
	S2S(INVALID_FTE)
	S2S(REQUESTED_TCLAS_NOT_SUPPORTED)
	S2S(INSUFFICIENT_TCLAS_PROCESSING_RESOURCES)
	S2S(TRY_ANOTHER_BSS)
	S2S(GAS_ADV_PROTO_NOT_SUPPORTED)
	S2S(NO_OUTSTANDING_GAS_REQ)
	S2S(GAS_RESP_NOT_RECEIVED)
	S2S(STA_TIMED_OUT_WAITING_FOR_GAS_RESP)
	S2S(GAS_RESP_LARGER_THAN_LIMIT)
	S2S(REQ_REFUSED_HOME)
	S2S(ADV_SRV_UNREACHABLE)
	S2S(REQ_REFUSED_SSPN)
	S2S(REQ_REFUSED_UNAUTH_ACCESS)
	S2S(INVALID_RSNE)
	S2S(U_APSD_COEX_NOT_SUPPORTED)
	S2S(U_APSD_COEX_MODE_NOT_SUPPORTED)
	S2S(BAD_INTERVAL_WITH_U_APSD_COEX)
	S2S(ANTI_CLOGGING_TOKEN_REQ)
	S2S(FINITE_CYCLIC_GROUP_NOT_SUPPORTED)
	S2S(CANNOT_FIND_ALT_TBTT)
	S2S(TRANSMISSION_FAILURE)
	S2S(REQ_TCLAS_NOT_SUPPORTED)
	S2S(TCLAS_RESOURCES_EXCHAUSTED)
	S2S(REJECTED_WITH_SUGGESTED_BSS_TRANSITION)
	S2S(REJECT_WITH_SCHEDULE)
	S2S(REJECT_NO_WAKEUP_SPECIFIED)
	S2S(SUCCESS_POWER_SAVE_MODE)
	S2S(PENDING_ADMITTING_FST_SESSION)
	S2S(PERFORMING_FST_NOW)
	S2S(PENDING_GAP_IN_BA_WINDOW)
	S2S(REJECT_U_PID_SETTING)
	S2S(REFUSED_EXTERNAL_REASON)
	S2S(REFUSED_AP_OUT_OF_MEMORY)
	S2S(REJECTED_EMERGENCY_SERVICE_NOT_SUPPORTED)
	S2S(QUERY_RESP_OUTSTANDING)
	S2S(REJECT_DSE_BAND)
	S2S(TCLAS_PROCESSING_TERMINATED)
	S2S(TS_SCHEDULE_CONFLICT)
	S2S(DENIED_WITH_SUGGESTED_BAND_AND_CHANNEL)
	S2S(MCCAOP_RESERVATION_CONFLICT)
	S2S(MAF_LIMIT_EXCEEDED)
	S2S(MCCA_TRACK_LIMIT_EXCEEDED)
	S2S(DENIED_DUE_TO_SPECTRUM_MANAGEMENT)
	S2S(ASSOC_DENIED_NO_VHT)
	S2S(ENABLEMENT_DENIED)
	S2S(RESTRICTION_FROM_AUTHORIZED_GDB)
	S2S(AUTHORIZATION_DEENABLED)
	S2S(FILS_AUTHENTICATION_FAILURE)
	S2S(UNKNOWN_AUTHENTICATION_SERVER)
	S2S(UNKNOWN_PASSWORD_IDENTIFIER)
	S2S(DENIED_HE_NOT_SUPPORTED)
	S2S(SAE_HASH_TO_ELEMENT)
	S2S(SAE_PK)
	S2S(INVALID_PUBLIC_KEY)
	S2S(PASN_BASE_AKMP_FAILED)
	S2S(OCI_MISMATCH)
	}
	return "UNKNOWN";
#undef S2S
}


int mb_ies_info_by_ies(struct mb_ies_info *info, const u8 *ies_buf,
		       size_t ies_len)
{
	const struct element *elem;

	os_memset(info, 0, sizeof(*info));

	if (!ies_buf)
		return 0;

	for_each_element_id(elem, WLAN_EID_MULTI_BAND, ies_buf, ies_len) {
		if (info->nof_ies >= MAX_NOF_MB_IES_SUPPORTED)
			return 0;

		wpa_printf(MSG_DEBUG, "MB IE of %u bytes found",
			   elem->datalen + 2);
		info->ies[info->nof_ies].ie = elem->data;
		info->ies[info->nof_ies].ie_len = elem->datalen;
		info->nof_ies++;
	}

	if (!for_each_element_completed(elem, ies_buf, ies_len)) {
		wpa_hexdump(MSG_DEBUG, "Truncated IEs", ies_buf, ies_len);
		return -1;
	}

	return 0;
}


struct wpabuf * mb_ies_by_info(struct mb_ies_info *info)
{
	struct wpabuf *mb_ies = NULL;

	WPA_ASSERT(info != NULL);

	if (info->nof_ies) {
		u8 i;
		size_t mb_ies_size = 0;

		for (i = 0; i < info->nof_ies; i++)
			mb_ies_size += 2 + info->ies[i].ie_len;

		mb_ies = wpabuf_alloc(mb_ies_size);
		if (mb_ies) {
			for (i = 0; i < info->nof_ies; i++) {
				wpabuf_put_u8(mb_ies, WLAN_EID_MULTI_BAND);
				wpabuf_put_u8(mb_ies, info->ies[i].ie_len);
				wpabuf_put_data(mb_ies,
						info->ies[i].ie,
						info->ies[i].ie_len);
			}
		}
	}

	return mb_ies;
}


const struct oper_class_map global_op_class[] = {
	{ HOSTAPD_MODE_IEEE80211G, 81, 1, 13, 1, BW20, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211G, 82, 14, 14, 1, BW20, NO_P2P_SUPP },

	/* Do not enable HT40 on 2.4 GHz for P2P use for now */
	{ HOSTAPD_MODE_IEEE80211G, 83, 1, 9, 1, BW40PLUS, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211G, 84, 5, 13, 1, BW40MINUS, NO_P2P_SUPP },

	{ HOSTAPD_MODE_IEEE80211A, 115, 36, 48, 4, BW20, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 116, 36, 44, 8, BW40PLUS, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 117, 40, 48, 8, BW40MINUS, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 118, 52, 64, 4, BW20, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 119, 52, 60, 8, BW40PLUS, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 120, 56, 64, 8, BW40MINUS, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 121, 100, 144, 4, BW20, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 122, 100, 140, 8, BW40PLUS, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 123, 104, 144, 8, BW40MINUS, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 124, 149, 161, 4, BW20, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 125, 149, 177, 4, BW20, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 126, 149, 173, 8, BW40PLUS, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 127, 153, 177, 8, BW40MINUS, P2P_SUPP },

	/*
	 * IEEE Std 802.11ax-2021, Table E-4 actually talks about channel center
	 * frequency index for operation classes 128, 129, 130, 132, 133, 134,
	 * and 135, but currently use the lowest 20 MHz channel for simplicity
	 * (these center frequencies are not actual channels, which makes
	 * wpas_p2p_verify_channel() fail).
	 * Specially for the operation class 136, it is also defined to use the
	 * channel center frequency index value, but it happens to be a 20 MHz
	 * channel and the channel number in the channel set would match the
	 * value in for the frequency center.
	 *
	 * Operating class value pair 128 and 130 is used to describe a 80+80
	 * MHz channel on the 5 GHz band. 130 is identified with "80+", so this
	 * is encoded with two octets 130 and 128. Similarly, operating class
	 * value pair 133 and 135 is used to describe a 80+80 MHz channel on
	 * the 6 GHz band (135 being the one with "80+" indication). All other
	 * operating classes listed here are used as 1-octet values.
	 */
	{ HOSTAPD_MODE_IEEE80211A, 128, 36, 177, 4, BW80, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 129, 36, 177, 4, BW160, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 130, 36, 177, 4, BW80P80, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 131, 1, 233, 4, BW20, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 132, 1, 233, 8, BW40, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 133, 1, 233, 16, BW80, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 134, 1, 233, 32, BW160, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 135, 1, 233, 16, BW80P80, NO_P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211A, 136, 2, 2, 4, BW20, NO_P2P_SUPP },

	/* IEEE Std 802.11be-2024, Table E-4 (Global operating classes) */
	{ HOSTAPD_MODE_IEEE80211A, 137, 31, 191, 32, BW320, NO_P2P_SUPP },

	/*
	 * IEEE Std 802.11ad-2012 and P802.ay/D5.0 60 GHz operating classes.
	 * Class 180 has the legacy channels 1-6. Classes 181-183 include
	 * channels which implement channel bonding features.
	 */
	{ HOSTAPD_MODE_IEEE80211AD, 180, 1, 6, 1, BW2160, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211AD, 181, 9, 13, 1, BW4320, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211AD, 182, 17, 20, 1, BW6480, P2P_SUPP },
	{ HOSTAPD_MODE_IEEE80211AD, 183, 25, 27, 1, BW8640, P2P_SUPP },

	{ -1, 0, 0, 0, 0, BW20, NO_P2P_SUPP }
};


static enum phy_type ieee80211_phy_type_by_freq(int freq)
{
	enum hostapd_hw_mode hw_mode;
	u8 channel;

	hw_mode = ieee80211_freq_to_chan(freq, &channel);

	switch (hw_mode) {
	case HOSTAPD_MODE_IEEE80211A:
		return PHY_TYPE_OFDM;
	case HOSTAPD_MODE_IEEE80211B:
		return PHY_TYPE_HRDSSS;
	case HOSTAPD_MODE_IEEE80211G:
		return PHY_TYPE_ERP;
	case HOSTAPD_MODE_IEEE80211AD:
		return PHY_TYPE_DMG;
	default:
		return PHY_TYPE_UNSPECIFIED;
	};
}


/* ieee80211_get_phy_type - Derive the phy type by freq and bandwidth */
enum phy_type ieee80211_get_phy_type(int freq, bool ht, bool vht, bool he)
{
	if (he)
		return PHY_TYPE_HE;
	if (vht)
		return PHY_TYPE_VHT;
	if (ht)
		return PHY_TYPE_HT;

	return ieee80211_phy_type_by_freq(freq);
}


size_t global_op_class_size = ARRAY_SIZE(global_op_class);


/**
 * get_ie - Fetch a specified information element from IEs buffer
 * @ies: Information elements buffer
 * @len: Information elements buffer length
 * @eid: Information element identifier (WLAN_EID_*)
 * Returns: Pointer to the information element (id field) or %NULL if not found
 *
 * This function returns the first matching information element in the IEs
 * buffer or %NULL in case the element is not found.
 */
const u8 * get_ie(const u8 *ies, size_t len, u8 eid)
{
	const struct element *elem;

	if (!ies)
		return NULL;

	for_each_element_id(elem, eid, ies, len)
		return &elem->id;

	return NULL;
}


/**
 * get_ie_ext - Fetch a specified extended information element from IEs buffer
 * @ies: Information elements buffer
 * @len: Information elements buffer length
 * @ext: Information element extension identifier (WLAN_EID_EXT_*)
 * Returns: Pointer to the information element (id field) or %NULL if not found
 *
 * This function returns the first matching information element in the IEs
 * buffer or %NULL in case the element is not found.
 */
const u8 * get_ie_ext(const u8 *ies, size_t len, u8 ext)
{
	const struct element *elem;

	if (!ies)
		return NULL;

	for_each_element_extid(elem, ext, ies, len)
		return &elem->id;

	return NULL;
}


const u8 * get_vendor_ie(const u8 *ies, size_t len, u32 vendor_type)
{
	const struct element *elem;

	if (!ies)
		return NULL;

	for_each_element_id(elem, WLAN_EID_VENDOR_SPECIFIC, ies, len) {
		if (elem->datalen >= 4 &&
		    vendor_type == WPA_GET_BE32(elem->data))
			return &elem->id;
	}

	return NULL;
}


size_t mbo_add_ie(u8 *buf, size_t len, const u8 *attr, size_t attr_len)
{
	/*
	 * MBO IE requires 6 bytes without the attributes: EID (1), length (1),
	 * OUI (3), OUI type (1).
	 */
	if (len < 6 + attr_len) {
		wpa_printf(MSG_DEBUG,
			   "MBO: Not enough room in buffer for MBO IE: buf len = %zu, attr_len = %zu",
			   len, attr_len);
		return 0;
	}

	*buf++ = WLAN_EID_VENDOR_SPECIFIC;
	*buf++ = attr_len + 4;
	WPA_PUT_BE24(buf, OUI_WFA);
	buf += 3;
	*buf++ = MBO_OUI_TYPE;
	os_memcpy(buf, attr, attr_len);

	return 6 + attr_len;
}


u16 check_multi_ap_ie(const u8 *multi_ap_ie, size_t multi_ap_len,
		      struct multi_ap_params *multi_ap)
{
	const struct element *elem;
	bool ext_present = false;
	unsigned int vlan_id;

	os_memset(multi_ap, 0, sizeof(*multi_ap));

	/* Default profile is 1, when Multi-AP profile subelement is not
	 * present in the element. */
	multi_ap->profile = 1;

	for_each_element(elem, multi_ap_ie, multi_ap_len) {
		u8 id = elem->id, elen = elem->datalen;
		const u8 *pos = elem->data;

		switch (id) {
		case MULTI_AP_SUB_ELEM_TYPE:
			if (elen >= 1) {
				multi_ap->capability = *pos;
				ext_present = true;
			} else {
				wpa_printf(MSG_DEBUG,
					   "Multi-AP invalid Multi-AP subelement");
				return WLAN_STATUS_INVALID_ELEMENT;
			}
			break;
		case MULTI_AP_PROFILE_SUB_ELEM_TYPE:
			if (elen < 1) {
				wpa_printf(MSG_DEBUG,
					   "Multi-AP IE invalid Multi-AP profile subelement");
				return WLAN_STATUS_INVALID_ELEMENT;
			}

			multi_ap->profile = *pos;
			if (multi_ap->profile > MULTI_AP_PROFILE_MAX) {
				wpa_printf(MSG_DEBUG,
					   "Multi-AP IE with invalid profile 0x%02x",
					   multi_ap->profile);
				return WLAN_STATUS_ASSOC_DENIED_UNSPEC;
			}
			break;
		case MULTI_AP_VLAN_SUB_ELEM_TYPE:
			if (multi_ap->profile < MULTI_AP_PROFILE_2) {
				wpa_printf(MSG_DEBUG,
					   "Multi-AP IE invalid profile to read VLAN IE");
				return WLAN_STATUS_INVALID_ELEMENT;
			}
			if (elen < 2) {
				wpa_printf(MSG_DEBUG,
					   "Multi-AP IE invalid Multi-AP VLAN subelement");
				return WLAN_STATUS_INVALID_ELEMENT;
			}

			vlan_id = WPA_GET_LE16(pos);
			if (vlan_id < 1 || vlan_id > 4094) {
				wpa_printf(MSG_INFO,
					   "Multi-AP IE invalid Multi-AP VLAN ID %d",
					   vlan_id);
				return WLAN_STATUS_INVALID_ELEMENT;
			}
			multi_ap->vlanid = vlan_id;
			break;
		default:
			wpa_printf(MSG_DEBUG,
				   "Ignore unknown subelement %u in Multi-AP IE",
				   id);
			break;
		}
	}

	if (!for_each_element_completed(elem, multi_ap_ie, multi_ap_len)) {
		wpa_printf(MSG_DEBUG, "Multi AP IE parse failed @%d",
			   (int) (multi_ap_ie + multi_ap_len -
				  (const u8 *) elem));
		wpa_hexdump(MSG_MSGDUMP, "IEs", multi_ap_ie, multi_ap_len);
	}

	if (!ext_present) {
		wpa_printf(MSG_DEBUG,
			   "Multi-AP element without Multi-AP Extension subelement");
		return WLAN_STATUS_INVALID_ELEMENT;
	}

	return WLAN_STATUS_SUCCESS;
}


size_t add_multi_ap_ie(u8 *buf, size_t len,
		       const struct multi_ap_params *multi_ap)
{
	u8 *pos = buf;
	u8 *len_ptr;

	if (len < 6)
		return 0;

	*pos++ = WLAN_EID_VENDOR_SPECIFIC;
	len_ptr = pos; /* Length field to be set at the end */
	pos++;
	WPA_PUT_BE24(pos, OUI_WFA);
	pos += 3;
	*pos++ = MULTI_AP_OUI_TYPE;

	/* Multi-AP Extension subelement */
	if (buf + len - pos < 3)
		return 0;
	*pos++ = MULTI_AP_SUB_ELEM_TYPE;
	*pos++ = 1; /* len */
	*pos++ = multi_ap->capability;

	/* Add Multi-AP Profile subelement only for R2 or newer configuration */
	if (multi_ap->profile >= MULTI_AP_PROFILE_2) {
		if (buf + len - pos < 3)
			return 0;
		*pos++ = MULTI_AP_PROFILE_SUB_ELEM_TYPE;
		*pos++ = 1;
		*pos++ = multi_ap->profile;
	}

	/* Add Multi-AP Default 802.1Q Setting subelement only for backhaul BSS
	 */
	if (multi_ap->vlanid &&
	    multi_ap->profile >= MULTI_AP_PROFILE_2 &&
	    (multi_ap->capability & MULTI_AP_BACKHAUL_BSS)) {
		if (buf + len - pos < 4)
			return 0;
		*pos++ = MULTI_AP_VLAN_SUB_ELEM_TYPE;
		*pos++ = 2;
		WPA_PUT_LE16(pos, multi_ap->vlanid);
		pos += 2;
	}

	*len_ptr = pos - len_ptr - 1;

	return pos - buf;
}


static const struct country_op_class us_op_class[] = {
	{ 1, 115 },
	{ 2, 118 },
	{ 3, 124 },
	{ 4, 121 },
	{ 5, 125 },
	{ 12, 81 },
	{ 22, 116 },
	{ 23, 119 },
	{ 24, 122 },
	{ 25, 126 },
	{ 26, 126 },
	{ 27, 117 },
	{ 28, 120 },
	{ 29, 123 },
	{ 30, 127 },
	{ 31, 127 },
	{ 32, 83 },
	{ 33, 84 },
	{ 34, 180 },
};

static const struct country_op_class eu_op_class[] = {
	{ 1, 115 },
	{ 2, 118 },
	{ 3, 121 },
	{ 4, 81 },
	{ 5, 116 },
	{ 6, 119 },
	{ 7, 122 },
	{ 8, 117 },
	{ 9, 120 },
	{ 10, 123 },
	{ 11, 83 },
	{ 12, 84 },
	{ 17, 125 },
	{ 18, 180 },
};

static const struct country_op_class jp_op_class[] = {
	{ 1, 115 },
	{ 30, 81 },
	{ 31, 82 },
	{ 32, 118 },
	{ 33, 118 },
	{ 34, 121 },
	{ 35, 121 },
	{ 36, 116 },
	{ 37, 119 },
	{ 38, 119 },
	{ 39, 122 },
	{ 40, 122 },
	{ 41, 117 },
	{ 42, 120 },
	{ 43, 120 },
	{ 44, 123 },
	{ 45, 123 },
	{ 56, 83 },
	{ 57, 84 },
	{ 58, 121 },
	{ 59, 180 },
};

static const struct country_op_class cn_op_class[] = {
	{ 1, 115 },
	{ 2, 118 },
	{ 3, 125 },
	{ 4, 116 },
	{ 5, 119 },
	{ 6, 126 },
	{ 7, 81 },
	{ 8, 83 },
	{ 9, 84 },
};

static u8
global_op_class_from_country_array(u8 op_class, size_t array_size,
				   const struct country_op_class *country_array)
{
	size_t i;

	for (i = 0; i < array_size; i++) {
		if (country_array[i].country_op_class == op_class)
			return country_array[i].global_op_class;
	}

	return 0;
}


u8 country_to_global_op_class(const char *country, u8 op_class)
{
	const struct country_op_class *country_array;
	size_t size;
	u8 g_op_class;

	if (country_match(us_op_class_cc, country)) {
		country_array = us_op_class;
		size = ARRAY_SIZE(us_op_class);
	} else if (country_match(eu_op_class_cc, country)) {
		country_array = eu_op_class;
		size = ARRAY_SIZE(eu_op_class);
	} else if (country_match(jp_op_class_cc, country)) {
		country_array = jp_op_class;
		size = ARRAY_SIZE(jp_op_class);
	} else if (country_match(cn_op_class_cc, country)) {
		country_array = cn_op_class;
		size = ARRAY_SIZE(cn_op_class);
	} else {
		/*
		 * Countries that do not match any of the above countries use
		 * global operating classes
		 */
		return op_class;
	}

	g_op_class = global_op_class_from_country_array(op_class, size,
							country_array);

	/*
	 * If the given operating class did not match any of the country's
	 * operating classes, assume that global operating class is used.
	 */
	return g_op_class ? g_op_class : op_class;
}


const struct oper_class_map * get_oper_class(const char *country, u8 op_class)
{
	const struct oper_class_map *op;

	if (country)
		op_class = country_to_global_op_class(country, op_class);

	op = &global_op_class[0];
	while (op->op_class && op->op_class != op_class)
		op++;

	if (!op->op_class)
		return NULL;

	return op;
}


int oper_class_bw_to_int(const struct oper_class_map *map)
{
	switch (map->bw) {
	case BW20:
		return 20;
	case BW40:
	case BW40PLUS:
	case BW40MINUS:
		return 40;
	case BW80:
		return 80;
	case BW80P80:
	case BW160:
		return 160;
	case BW320:
		return 320;
	case BW2160:
		return 2160;
	default:
		return 0;
	}
}


bool is_24ghz_freq(int freq)
{
	return freq >= 2400 && freq <= 2484;
}


bool is_5ghz_freq(int freq)
{
	return freq >= 5150 && freq <= 5885;
}


int center_idx_to_bw_6ghz(u8 idx)
{
	/* Channel: 2 */
	if (idx == 2)
		return 0; /* 20 MHz */
	/* channels: 1, 5, 9, 13... */
	if ((idx & 0x3) == 0x1)
		return 0; /* 20 MHz */
	/* channels 3, 11, 19... */
	if ((idx & 0x7) == 0x3)
		return 1; /* 40 MHz */
	/* channels 7, 23, 39.. */
	if ((idx & 0xf) == 0x7)
		return 2; /* 80 MHz */
	/* channels 15, 47, 79...*/
	if ((idx & 0x1f) == 0xf)
		return 3; /* 160 MHz */
	/* channels 31, 63, 95, 127, 159, 191 */
	if ((idx & 0x1f) == 0x1f && idx < 192)
		return 4; /* 320 MHz */

	return -1;
}


bool is_6ghz_freq(int freq)
{
	if (freq < 5935 || freq > 7115)
		return false;

	if (freq == 5935)
		return true;

	if (center_idx_to_bw_6ghz((freq - 5950) / 5) < 0)
		return false;

	return true;
}


bool is_6ghz_op_class(u8 op_class)
{
	return op_class >= 131 && op_class <= 137;
}


bool is_6ghz_psc_frequency(int freq)
{
	int i;

	if (!is_6ghz_freq(freq) || freq == 5935)
		return false;
	if ((((freq - 5950) / 5) & 0x3) != 0x1)
		return false;

	i = (freq - 5950 + 55) % 80;
	if (i == 0)
		i = (freq - 5950 + 55) / 80;

	if (i >= 1 && i <= 15)
		return true;

	return false;
}


/**
 * get_6ghz_sec_channel - Get the relative position of the secondary channel
 * to the primary channel in 6 GHz
 * @channel: Primary channel to be checked for (in global op class 131)
 * Returns: 1 = secondary channel above, -1 = secondary channel below
 */

int get_6ghz_sec_channel(int channel)
{
	/*
	 * In the 6 GHz band, primary channels are numbered as 1, 5, 9, 13.., so
	 * the 40 MHz channels are formed with the channel pairs as (1,5),
	 * (9,13), (17,21)..
	 * The secondary channel for a given primary channel is below the
	 * primary channel for the channels 5, 13, 21.. and it is above the
	 * primary channel for the channels 1, 9, 17..
	 */

	if (((channel - 1) / 4) % 2)
		return -1;
	return 1;
}


bool is_same_band(int freq1, int freq2)
{
	if (IS_2P4GHZ(freq1) && IS_2P4GHZ(freq2))
		return true;

	if (IS_5GHZ(freq1) && IS_5GHZ(freq2))
		return true;

	if (is_6ghz_freq(freq1) && is_6ghz_freq(freq2))
		return true;

	return false;
}


int ieee802_11_parse_candidate_list(const char *pos, u8 *nei_rep,
				    size_t nei_rep_len)
{
	u8 *nei_pos = nei_rep;
	const char *end;

	/*
	 * BSS Transition Candidate List Entries - Neighbor Report elements
	 * neighbor=<BSSID>,<BSSID Information>,<Operating Class>,
	 * <Channel Number>,<PHY Type>[,<hexdump of Optional Subelements>]
	 */
	while (pos) {
		u8 *nei_start;
		long int val;
		char *endptr, *tmp;

		pos = os_strstr(pos, " neighbor=");
		if (!pos)
			break;
		if (nei_pos + 15 > nei_rep + nei_rep_len) {
			wpa_printf(MSG_DEBUG,
				   "Not enough room for additional neighbor");
			return -1;
		}
		pos += 10;

		nei_start = nei_pos;
		*nei_pos++ = WLAN_EID_NEIGHBOR_REPORT;
		nei_pos++; /* length to be filled in */

		if (hwaddr_aton(pos, nei_pos)) {
			wpa_printf(MSG_DEBUG, "Invalid BSSID");
			return -1;
		}
		nei_pos += ETH_ALEN;
		pos += 17;
		if (*pos != ',') {
			wpa_printf(MSG_DEBUG, "Missing BSSID Information");
			return -1;
		}
		pos++;

		val = strtol(pos, &endptr, 0);
		WPA_PUT_LE32(nei_pos, val);
		nei_pos += 4;
		if (*endptr != ',') {
			wpa_printf(MSG_DEBUG, "Missing Operating Class");
			return -1;
		}
		pos = endptr + 1;

		*nei_pos++ = atoi(pos); /* Operating Class */
		pos = os_strchr(pos, ',');
		if (pos == NULL) {
			wpa_printf(MSG_DEBUG, "Missing Channel Number");
			return -1;
		}
		pos++;

		*nei_pos++ = atoi(pos); /* Channel Number */
		pos = os_strchr(pos, ',');
		if (pos == NULL) {
			wpa_printf(MSG_DEBUG, "Missing PHY Type");
			return -1;
		}
		pos++;

		*nei_pos++ = atoi(pos); /* PHY Type */
		end = os_strchr(pos, ' ');
		tmp = os_strchr(pos, ',');
		if (tmp && (!end || tmp < end)) {
			/* Optional Subelements (hexdump) */
			size_t len;

			pos = tmp + 1;
			end = os_strchr(pos, ' ');
			if (end)
				len = end - pos;
			else
				len = os_strlen(pos);
			if (nei_pos + len / 2 > nei_rep + nei_rep_len) {
				wpa_printf(MSG_DEBUG,
					   "Not enough room for neighbor subelements");
				return -1;
			}
			if (len & 0x01 ||
			    hexstr2bin(pos, nei_pos, len / 2) < 0) {
				wpa_printf(MSG_DEBUG,
					   "Invalid neighbor subelement info");
				return -1;
			}
			nei_pos += len / 2;
			pos = end;
		}

		nei_start[1] = nei_pos - nei_start - 2;
	}

	return nei_pos - nei_rep;
}


int ieee802_11_ext_capab(const u8 *ie, unsigned int capab)
{
	if (!ie || ie[1] <= capab / 8)
		return 0;
	return !!(ie[2 + capab / 8] & BIT(capab % 8));
}


bool ieee802_11_rsnx_capab_len(const u8 *rsnxe, size_t rsnxe_len,
			       unsigned int capab)
{
	const u8 *end;
	size_t flen, i;
	u64 capabs = 0;

	if (!rsnxe || rsnxe_len == 0)
		return false;

	if (capab > 63) {
		wpa_printf(MSG_INFO, "%s: Unsupported capab=%u",
			   __func__, capab);
		return false;
	}

	end = rsnxe + rsnxe_len;
	flen = (rsnxe[0] & 0x0f) + 1;
	if (rsnxe + flen > end)
		return false;
	if (flen > 8)
		flen = 8;
	for (i = 0; i < flen; i++)
		capabs |= (u64) rsnxe[i] << (8 * i);

	return !!(capabs & BIT_ULL(capab));
}


bool ieee802_11_rsnx_capab(const u8 *rsnxe, unsigned int capab)
{
	if (!rsnxe)
		return false;
	if (rsnxe[0] == WLAN_EID_VENDOR_SPECIFIC && rsnxe[1] >= 4 + 1)
		return ieee802_11_rsnx_capab_len(rsnxe + 2 + 4, rsnxe[1] - 4,
						 capab);
	return ieee802_11_rsnx_capab_len(rsnxe + 2, rsnxe[1], capab);
}


void hostapd_encode_edmg_chan(int edmg_enable, u8 edmg_channel,
			      int primary_channel,
			      struct ieee80211_edmg_config *edmg)
{
	if (!edmg_enable) {
		edmg->channels = 0;
		edmg->bw_config = 0;
		return;
	}

	/* Only EDMG CB1 and EDMG CB2 contiguous channels supported for now */
	switch (edmg_channel) {
	case EDMG_CHANNEL_9:
		edmg->channels = EDMG_CHANNEL_9_SUBCHANNELS;
		edmg->bw_config = EDMG_BW_CONFIG_5;
		return;
	case EDMG_CHANNEL_10:
		edmg->channels = EDMG_CHANNEL_10_SUBCHANNELS;
		edmg->bw_config = EDMG_BW_CONFIG_5;
		return;
	case EDMG_CHANNEL_11:
		edmg->channels = EDMG_CHANNEL_11_SUBCHANNELS;
		edmg->bw_config = EDMG_BW_CONFIG_5;
		return;
	case EDMG_CHANNEL_12:
		edmg->channels = EDMG_CHANNEL_12_SUBCHANNELS;
		edmg->bw_config = EDMG_BW_CONFIG_5;
		return;
	case EDMG_CHANNEL_13:
		edmg->channels = EDMG_CHANNEL_13_SUBCHANNELS;
		edmg->bw_config = EDMG_BW_CONFIG_5;
		return;
	default:
		if (primary_channel > 0 && primary_channel < 7) {
			edmg->channels = BIT(primary_channel - 1);
			edmg->bw_config = EDMG_BW_CONFIG_4;
		} else {
			edmg->channels = 0;
			edmg->bw_config = 0;
		}
		break;
	}
}


/* Check if the requested EDMG configuration is a subset of the allowed
 * EDMG configuration. */
int ieee802_edmg_is_allowed(struct ieee80211_edmg_config allowed,
			    struct ieee80211_edmg_config requested)
{
	/*
	 * The validation check if the requested EDMG configuration
	 * is a subset of the allowed EDMG configuration:
	 * 1. Check that the requested channels are part (set) of the allowed
	 * channels.
	 * 2. P802.11ay defines the values of bw_config between 4 and 15.
	 * (bw config % 4) will give us 4 groups inside bw_config definition,
	 * inside each group we can check the subset just by comparing the
	 * bw_config value.
	 * Between this 4 groups, there is no subset relation - as a result of
	 * the P802.11ay definition.
	 * bw_config defined by IEEE P802.11ay/D4.0, 9.4.2.251, Table 13.
	 */
	if (((requested.channels & allowed.channels) != requested.channels) ||
	    ((requested.bw_config % 4) > (allowed.bw_config % 4)) ||
	    requested.bw_config > allowed.bw_config)
		return 0;

	return 1;
}


int op_class_to_bandwidth(u8 op_class)
{
	switch (op_class) {
	case 81:
	case 82:
		return 20;
	case 83: /* channels 1..9; 40 MHz */
	case 84: /* channels 5..13; 40 MHz */
		return 40;
	case 115: /* channels 36,40,44,48; indoor only */
		return 20;
	case 116: /* channels 36,44; 40 MHz; indoor only */
	case 117: /* channels 40,48; 40 MHz; indoor only */
		return 40;
	case 118: /* channels 52,56,60,64; dfs */
		return 20;
	case 119: /* channels 52,60; 40 MHz; dfs */
	case 120: /* channels 56,64; 40 MHz; dfs */
		return 40;
	case 121: /* channels 100-144 */
		return 20;
	case 122: /* channels 100-140; 40 MHz */
	case 123: /* channels 104-144; 40 MHz */
		return 40;
	case 124: /* channels 149,153,157,161 */
	case 125: /* channels 149,153,157,161,165,169,173,177 */
		return 20;
	case 126: /* channels 149,157,161,165,169,173; 40 MHz */
	case 127: /* channels 153..177; 40 MHz */
		return 40;
	case 128: /* center freqs 42, 58, 106, 122, 138, 155, 171; 80 MHz */
		return 80;
	case 129: /* center freqs 50, 114, 163; 160 MHz */
		return 160;
	case 130: /* center freqs 42, 58, 106, 122, 138, 155, 171; 80+80 MHz */
		return 80;
	case 131: /* UHB channels, 20 MHz: 1, 5, 9.. */
		return 20;
	case 132: /* UHB channels, 40 MHz: 3, 11, 19.. */
		return 40;
	case 133: /* UHB channels, 80 MHz: 7, 23, 39.. */
		return 80;
	case 134: /* UHB channels, 160 MHz: 15, 47, 79.. */
	case 135: /* UHB channels, 80+80 MHz: 7, 23, 39.. */
		return 160;
	case 136: /* UHB channels, 20 MHz: 2 */
		return 20;
	case 137: /* UHB channels, 320 MHz: 31, 63, 95, 127, 159, 191 */
		return 320;
	case 180: /* 60 GHz band, channels 1..8 */
		return 2160;
	case 181: /* 60 GHz band, EDMG CB2, channels 9..15 */
		return 4320;
	case 182: /* 60 GHz band, EDMG CB3, channels 17..22 */
		return 6480;
	case 183: /* 60 GHz band, EDMG CB4, channel 25..29 */
		return 8640;
	default:
		return 20;
	}
}


enum oper_chan_width op_class_to_ch_width(u8 op_class)
{
	switch (op_class) {
	case 81:
	case 82:
		return CONF_OPER_CHWIDTH_USE_HT;
	case 83: /* channels 1..9; 40 MHz */
	case 84: /* channels 5..13; 40 MHz */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 115: /* channels 36,40,44,48; indoor only */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 116: /* channels 36,44; 40 MHz; indoor only */
	case 117: /* channels 40,48; 40 MHz; indoor only */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 118: /* channels 52,56,60,64; dfs */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 119: /* channels 52,60; 40 MHz; dfs */
	case 120: /* channels 56,64; 40 MHz; dfs */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 121: /* channels 100-144 */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 122: /* channels 100-140; 40 MHz */
	case 123: /* channels 104-144; 40 MHz */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 124: /* channels 149,153,157,161 */
	case 125: /* channels 149,153,157,161,165,169,171 */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 126: /* channels 149,157,165, 173; 40 MHz */
	case 127: /* channels 153,161,169,177; 40 MHz */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 128: /* center freqs 42, 58, 106, 122, 138, 155, 171; 80 MHz */
		return CONF_OPER_CHWIDTH_80MHZ;
	case 129: /* center freqs 50, 114, 163; 160 MHz */
		return CONF_OPER_CHWIDTH_160MHZ;
	case 130: /* center freqs 42, 58, 106, 122, 138, 155, 171; 80+80 MHz */
		return CONF_OPER_CHWIDTH_80P80MHZ;
	case 131: /* UHB channels, 20 MHz: 1, 5, 9.. */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 132: /* UHB channels, 40 MHz: 3, 11, 19.. */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 133: /* UHB channels, 80 MHz: 7, 23, 39.. */
		return CONF_OPER_CHWIDTH_80MHZ;
	case 134: /* UHB channels, 160 MHz: 15, 47, 79.. */
		return CONF_OPER_CHWIDTH_160MHZ;
	case 135: /* UHB channels, 80+80 MHz: 7, 23, 39.. */
		return CONF_OPER_CHWIDTH_80P80MHZ;
	case 136: /* UHB channels, 20 MHz: 2 */
		return CONF_OPER_CHWIDTH_USE_HT;
	case 137: /* UHB channels, 320 MHz: 31, 63, 95, 127, 159, 191 */
		return CONF_OPER_CHWIDTH_320MHZ;
	case 180: /* 60 GHz band, channels 1..8 */
		return CONF_OPER_CHWIDTH_2160MHZ;
	case 181: /* 60 GHz band, EDMG CB2, channels 9..15 */
		return CONF_OPER_CHWIDTH_4320MHZ;
	case 182: /* 60 GHz band, EDMG CB3, channels 17..22 */
		return CONF_OPER_CHWIDTH_6480MHZ;
	case 183: /* 60 GHz band, EDMG CB4, channel 25..29 */
		return CONF_OPER_CHWIDTH_8640MHZ;
	default:
		return CONF_OPER_CHWIDTH_USE_HT;
	}
}


/**
 * chwidth_freq2_to_ch_width - Determine channel width as enum oper_chan_width
 * @chwidth: Channel width integer
 * @freq2: Value for frequency 2. 0 is not used
 * Returns: enum oper_chan_width, -1 on failure
 */
int chwidth_freq2_to_ch_width(int chwidth, int freq2)
{
	if (freq2 < 0)
		return -1;
	if (freq2)
		return CONF_OPER_CHWIDTH_80P80MHZ;

	switch (chwidth) {
	case 0:
	case 20:
	case 40:
		return CONF_OPER_CHWIDTH_USE_HT;
	case 80:
		return CONF_OPER_CHWIDTH_80MHZ;
	case 160:
		return CONF_OPER_CHWIDTH_160MHZ;
	case 320:
		return CONF_OPER_CHWIDTH_320MHZ;
	default:
		wpa_printf(MSG_DEBUG, "Unknown max oper bandwidth: %d",
			   chwidth);
		return -1;
	}
}


enum oper_chan_width chan_width_to_oper_chwidth(enum chan_width chan_width)
{
	switch (chan_width) {
	case CHAN_WIDTH_20_NOHT:
	case CHAN_WIDTH_20:
	case CHAN_WIDTH_40:
		return CONF_OPER_CHWIDTH_USE_HT;
	case CHAN_WIDTH_80:
		return CONF_OPER_CHWIDTH_80MHZ;
	case CHAN_WIDTH_80P80:
		return CONF_OPER_CHWIDTH_80P80MHZ;
	case CHAN_WIDTH_160:
		return CONF_OPER_CHWIDTH_160MHZ;
	case CHAN_WIDTH_320:
		return CONF_OPER_CHWIDTH_320MHZ;
	default:
		return CONF_OPER_CHWIDTH_USE_HT;
	}
}


struct wpabuf * ieee802_11_defrag(const u8 *data, size_t len, bool ext_elem)
{
	struct wpabuf *buf;
	const u8 *pos, *end;
	size_t min_defrag_len = ext_elem ? 255 : 256;

	if (!data || !len)
		return NULL;

	if (len < min_defrag_len)
		return wpabuf_alloc_copy(data, len);

	buf = wpabuf_alloc_copy(data, min_defrag_len - 1);
	if (!buf)
		return NULL;

	pos = &data[min_defrag_len - 1];
	end = data + len;
	len -= min_defrag_len - 1;
	while (len > 2 && pos[0] == WLAN_EID_FRAGMENT && pos[1]) {
		int ret;
		size_t elen = 2 + pos[1];

		if (elen > (size_t) (end - pos) || elen > len)
			break;
		ret = wpabuf_resize(&buf, pos[1]);
		if (ret < 0) {
			wpabuf_free(buf);
			return NULL;
		}

		/* Copy only the fragment data (without the EID and length) */
		wpabuf_put_data(buf, &pos[2], pos[1]);
		pos += elen;
		len -= elen;
	}

	return buf;
}


/**
 * ieee802_11_defrag_mle_subelem - Defragment Multi-Link element subelements
 * @mlbuf: Defragmented mlbuf (defragmented using ieee802_11_defrag())
 * @parent_subelem: Pointer to the subelement which may be fragmented
 * @defrag_len: Defragmented length of the subelement
 * Returns: Number of Fragment subelements parsed on success, -1 otherwise
 *
 * This function defragments a subelement present inside an Multi-Link element.
 * It should be called individually for each subelement.
 *
 * Subelements can use the Fragment subelement if they pack more than 255 bytes
 * of data, see IEEE Std 802.11be-2024, Figure 35-4 - Per-STA Profile subelement
 * fragmentation within a fragmented Multi-Link element.
 */
ssize_t ieee802_11_defrag_mle_subelem(struct wpabuf *mlbuf,
				      const u8 *parent_subelem,
				      size_t *defrag_len)
{
	u8 *buf, *pos, *end;
	size_t len, subelem_len;
	const size_t min_defrag_len = 255;
	int num_frag_subelems = 0;

	if (!mlbuf || !parent_subelem)
		return -1;

	buf = wpabuf_mhead_u8(mlbuf);
	len = wpabuf_len(mlbuf);
	end = buf + len;

	*defrag_len = parent_subelem[1];
	if (parent_subelem[1] < min_defrag_len)
		return 0;

	pos = (u8 *) parent_subelem;
	if (2 + parent_subelem[1] > end - pos)
		return -1;
	pos += 2 + parent_subelem[1];
	subelem_len = parent_subelem[1];

	while (end - pos > 2 &&
	       pos[0] == MULTI_LINK_SUB_ELEM_ID_FRAGMENT && pos[1]) {
		size_t elen = 2 + pos[1];

		/* This Multi-Link parent subelement has more data and is
		 * fragmented. */
		num_frag_subelems++;

		if (elen > (size_t) (end - pos))
			return -1;

		os_memmove(pos, pos + 2, end - (pos + 2));
		end -= 2;
		mlbuf->used -= 2;
		pos += elen - 2;
		subelem_len += elen - 2;

		/* Deduct Fragment subelement header */
		len -= 2;
	}

	*defrag_len = subelem_len;
	return num_frag_subelems;
}


const u8 * get_ml_ie(const u8 *ies, size_t len, u8 type)
{
	const struct element *elem;

	if (!ies)
		return NULL;

	for_each_element_extid(elem, WLAN_EID_EXT_MULTI_LINK, ies, len) {
		if (elem->datalen >= 2 &&
		    (elem->data[1] & MULTI_LINK_CONTROL_TYPE_MASK) == type)
			return &elem->id;
	}

	return NULL;
}


const u8 * get_basic_mle_mld_addr(const u8 *buf, size_t len)
{
	const size_t mld_addr_pos =
		2 /* Control field */ +
		1 /* Common Info Length field */;
	const size_t fixed_len = mld_addr_pos +
		ETH_ALEN /* MLD MAC Address field */;

	if (len < fixed_len)
		return NULL;

	if ((buf[0] & MULTI_LINK_CONTROL_TYPE_MASK) !=
	    MULTI_LINK_CONTROL_TYPE_BASIC)
		return NULL;

	return &buf[mld_addr_pos];
}


const u8 * get_basic_mle_eml_capa(const u8 *buf, size_t len)
{
	const struct ieee80211_eht_ml *ml =
		(const struct ieee80211_eht_ml *) buf;
	u16 ctrl;
	size_t eml_capa_pos =
		MULTI_LINK_CONTROL_LEN + /* Multi-Link Control field */
		1 + /* Common Info Length field (Basic) */
		ETH_ALEN; /* MLD MAC Address field (Basic) */
	size_t common_info_limit;
	u8 common_info_len;

	if (len < MULTI_LINK_CONTROL_LEN)
		return NULL;

	ctrl = le_to_host16(ml->ml_control);
	if ((ctrl & MULTI_LINK_CONTROL_TYPE_MASK) !=
	    MULTI_LINK_CONTROL_TYPE_BASIC)
		return NULL;
	if (!(ctrl & BASIC_MULTI_LINK_CTRL_PRES_EML_CAPA))
		return NULL;

	/* Validate Common Info Length against available data */
	common_info_len = buf[MULTI_LINK_CONTROL_LEN];
	if (len < (size_t) MULTI_LINK_CONTROL_LEN + common_info_len)
		return NULL;
	common_info_limit = MULTI_LINK_CONTROL_LEN + common_info_len;

	if (ctrl & BASIC_MULTI_LINK_CTRL_PRES_LINK_ID)
		eml_capa_pos += EHT_ML_LINK_ID_LEN;

	if (ctrl & BASIC_MULTI_LINK_CTRL_PRES_BSS_PARAM_CH_COUNT)
		eml_capa_pos++;

	if (ctrl & BASIC_MULTI_LINK_CTRL_PRES_MSD_INFO)
		eml_capa_pos += 2;

	/* Ensure EML Capabilities field fits within the declared Common Info */
	if (eml_capa_pos + EHT_ML_EML_CAPA_LEN > common_info_limit)
		return NULL;

	return &buf[eml_capa_pos];
}


int get_basic_mle_link_id(const u8 *buf, size_t len)
{
	struct ieee80211_eht_ml *ml = (struct ieee80211_eht_ml *) buf;
	u16 ctrl;
	size_t link_id_pos =
		MULTI_LINK_CONTROL_LEN + /* Multi-Link Control field */
		1 + /* Common Info Length field (Basic) */
		ETH_ALEN; /* MLD MAC Address field (Basic) */
	size_t common_info_limit;
	u8 common_info_len;
	u8 link_id;

	if (len < MULTI_LINK_CONTROL_LEN)
		return -1;

	ctrl = le_to_host16(ml->ml_control);
	if ((ctrl & MULTI_LINK_CONTROL_TYPE_MASK) !=
	    MULTI_LINK_CONTROL_TYPE_BASIC)
		return -1;

	/* Validate Common Info Length against available data */
	common_info_len = buf[MULTI_LINK_CONTROL_LEN];
	if (len < (size_t) MULTI_LINK_CONTROL_LEN + common_info_len)
		return -1;
	common_info_limit = MULTI_LINK_CONTROL_LEN + common_info_len;

	if (!(ctrl & BASIC_MULTI_LINK_CTRL_PRES_LINK_ID))
		return -1;

	if (link_id_pos + EHT_ML_LINK_ID_LEN > common_info_limit)
		return -1;

	link_id = buf[link_id_pos] & BASIC_MLE_STA_CTRL_LINK_ID_MASK;
	if (link_id >= MAX_NUM_MLD_LINKS)
		return -1;

	return link_id;
}


/* Parse HT capabilities to get maximum number of supported spatial streams */
static int
parse_ht_mcs_set_for_max_nss(const struct ieee80211_ht_capabilities *htcaps,
			     bool parse_for_rx)
{
	int i, max_nss_rx = 1;
	u8 supported_tx_mcs_set, tx_mcs_set_defined, tx_rx_mcs_set_not_equal;

	if (!htcaps)
		return max_nss_rx;

	for (i = 4; i >= 1; i--) {
		if (htcaps->supported_mcs_set[i - 1] > 0) {
			max_nss_rx = i;
			break;
		}
	}
	if (parse_for_rx)
		return max_nss_rx;

	supported_tx_mcs_set = htcaps->supported_mcs_set[12];
	tx_mcs_set_defined = supported_tx_mcs_set & 0x1;
	tx_rx_mcs_set_not_equal = (supported_tx_mcs_set >> 1) & 0x1;
	if (tx_mcs_set_defined && tx_rx_mcs_set_not_equal) {
		u8 max_nss_tx_field_value = (supported_tx_mcs_set >> 2) & 0x3;

		/*
		 * The maximum number of Tx streams is 1 more than the field
		 * value.
		 */
		return max_nss_tx_field_value + 1;
	}

	return max_nss_rx;
}


/* Parse MCS map to get maximum number of supported spatial streams */
static unsigned int parse_mcs_map_for_max_nss(u16 mcs_map,
					      unsigned int max_streams_allowed)
{
	unsigned int i, max_nss = 1;

	for (i = max_streams_allowed; i >= 1; i--) {
		unsigned int stream_map = (mcs_map >> ((i - 1) * 2)) & 0x3;

		/* 3 means unsupported */
		if (stream_map != 3) {
			max_nss = i;
			break;
		}
	}

	return max_nss;
}


/* Parse capabilities elements to get maximum number of supported spatial
 * streams */
unsigned int get_max_nss_capability(struct ieee802_11_elems *elems,
				    bool parse_for_rx, enum chan_width bw)
{
	unsigned int max_nss = 1;
	struct ieee80211_ht_capabilities *htcaps =
		(struct ieee80211_ht_capabilities *) elems->ht_capabilities;
	struct ieee80211_vht_capabilities *vhtcaps =
		(struct ieee80211_vht_capabilities *) elems->vht_capabilities;
	struct ieee80211_he_capabilities *hecaps =
		(struct ieee80211_he_capabilities *) elems->he_capabilities;
	le16 mcs_map;

	if (hecaps) {
		unsigned int max_nss_he;
		const u8 *optional = hecaps->optional;

		if (bw == CHAN_WIDTH_160) {
			mcs_map = host_to_le16(
				WPA_GET_LE16(parse_for_rx ?
					     &optional[0] : &optional[2]));
		} else if (bw == CHAN_WIDTH_80P80) {
			mcs_map = host_to_le16(
				WPA_GET_LE16(parse_for_rx ?
					     &optional[4] : &optional[6]));
		} else {
			mcs_map = parse_for_rx ?
				hecaps->he_basic_supported_mcs_set.rx_map :
				hecaps->he_basic_supported_mcs_set.tx_map;
		}

		max_nss_he = parse_mcs_map_for_max_nss(
			le_to_host16(mcs_map), HE_NSS_MAX_STREAMS);
		if (max_nss_he > max_nss)
			max_nss = max_nss_he;
	} else if (vhtcaps) {
		unsigned int max_nss_vht;

		mcs_map = parse_for_rx ?
			vhtcaps->vht_supported_mcs_set.rx_map :
			vhtcaps->vht_supported_mcs_set.tx_map;
		max_nss_vht = parse_mcs_map_for_max_nss(
			le_to_host16(mcs_map), VHT_RX_NSS_MAX_STREAMS);
		if (max_nss_vht > max_nss)
			max_nss = max_nss_vht;
	} else if (htcaps) {
		unsigned int max_nss_ht;

		max_nss_ht = parse_ht_mcs_set_for_max_nss(htcaps, parse_for_rx);
		if (max_nss_ht > max_nss)
			max_nss = max_nss_ht;
	}

	return max_nss;
}


/* Parse VHT/HE capabilities elements to get supported channel width */
struct supported_chan_width
get_supported_channel_width(struct ieee802_11_elems *elems, int freq)
{
	struct supported_chan_width supported_width;
	struct ieee80211_ht_capabilities *htcaps;
	struct ieee80211_vht_capabilities *vhtcaps;
	struct ieee80211_he_capabilities *hecaps;
	struct ieee80211_eht_capabilities *ehtcaps;

	supported_width.is_40_supported = false;
	supported_width.is_160_supported = false;
	supported_width.is_80p80_supported = false;
	supported_width.is_320_supported = false;
	if (!elems)
		return supported_width;

	htcaps = (struct ieee80211_ht_capabilities *) elems->ht_capabilities;
	vhtcaps = (struct ieee80211_vht_capabilities *) elems->vht_capabilities;
	hecaps = (struct ieee80211_he_capabilities *) elems->he_capabilities;
	ehtcaps = (struct ieee80211_eht_capabilities *) elems->eht_capabilities;

	if (htcaps &&
	    (le_to_host16(htcaps->ht_capabilities_info) &
	     HT_CAP_INFO_SUPP_CHANNEL_WIDTH_SET))
		supported_width.is_40_supported = true;

	if (vhtcaps) {
		u32 vht_capabilities_info =
			le_to_host32(vhtcaps->vht_capabilities_info);

		if (vht_capabilities_info & VHT_CAP_SUPP_CHAN_WIDTH_160MHZ)
			supported_width.is_160_supported = true;
		if (vht_capabilities_info &
		    VHT_CAP_SUPP_CHAN_WIDTH_160_80PLUS80MHZ) {
			supported_width.is_160_supported = true;
			supported_width.is_80p80_supported = true;
		}
	}

	if (hecaps) {
		u8 channel_width_set = hecaps->he_phy_capab_info[
			HE_PHYCAP_CHANNEL_WIDTH_SET_IDX];

		/*
		 * The 40 MHz capability is band specific in HE: a bit for 2.4
		 * GHz vs. the shared 40/80 MHz bit for 5 GHz.
		 */
		if (is_24ghz_freq(freq)) {
			if (channel_width_set &
			    HE_PHYCAP_CHANNEL_WIDTH_SET_40MHZ_IN_2G)
				supported_width.is_40_supported = true;
		} else if (channel_width_set &
			   HE_PHYCAP_CHANNEL_WIDTH_SET_40MHZ_80MHZ_IN_5G) {
			supported_width.is_40_supported = true;
		}

		if (channel_width_set &
		    HE_PHYCAP_CHANNEL_WIDTH_SET_160MHZ_IN_5G)
			supported_width.is_160_supported = true;
		if (channel_width_set &
		    HE_PHYCAP_CHANNEL_WIDTH_SET_80PLUS80MHZ_IN_5G)
			supported_width.is_80p80_supported = true;
	}

	if (ehtcaps) {
		if (ehtcaps->phy_cap[EHT_PHYCAP_320MHZ_IN_6GHZ_SUPPORT_IDX] &
		    EHT_PHYCAP_320MHZ_IN_6GHZ_SUPPORT_MASK)
			supported_width.is_320_supported = true;
	}

	return supported_width;
}


/*
 * Parse VHT operation info fields to get operation channel width
 * note that VHT operation info fields could come from the VHT Operation element
 * or from the HE Operation element.
 */
static enum chan_width get_vht_operation_channel_width(
	const struct ieee80211_vht_operation *vht_oper_info)
{
	enum chan_width channel_width = CHAN_WIDTH_UNKNOWN;
	u8 seg0, seg1;

	switch (vht_oper_info->vht_op_info_chwidth) {
	case 1:
		seg0 = vht_oper_info->vht_op_info_chan_center_freq_seg0_idx;
		seg1 = vht_oper_info->vht_op_info_chan_center_freq_seg1_idx;
		if (seg1 && abs(seg1 - seg0) == 8)
			channel_width = CHAN_WIDTH_160;
		else if (seg1)
			channel_width = CHAN_WIDTH_80P80;
		else
			channel_width = CHAN_WIDTH_80;
		break;
	case 2:
		channel_width = CHAN_WIDTH_160;
		break;
	case 3:
		channel_width = CHAN_WIDTH_80P80;
		break;
	}

	return channel_width;
}


/* Parse 6 GHz operation info fields to get operation channel width */
static enum chan_width get_6ghz_operation_channel_width(
	const struct ieee80211_he_6ghz_oper_info *six_ghz_oper_info)
{
	enum chan_width channel_width = CHAN_WIDTH_UNKNOWN;
	u8 seg0, seg1;

	switch (six_ghz_oper_info->control &
		HE_6GHZ_OPER_INFO_CTRL_CHAN_WIDTH_MASK) {
	case 0:
		channel_width = CHAN_WIDTH_20;
		break;
	case 1:
		channel_width = CHAN_WIDTH_40;
		break;
	case 2:
		channel_width = CHAN_WIDTH_80;
		break;
	case 3:
		seg0 = six_ghz_oper_info->chan_center_freq_seg0;
		seg1 = six_ghz_oper_info->chan_center_freq_seg1;
		if (abs(seg1 - seg0) == 8)
			channel_width = CHAN_WIDTH_160;
		else
			channel_width = CHAN_WIDTH_80P80;
		break;
	}

	return channel_width;
}


/* Parse HE Operation element to get HE operation channel width */
static enum chan_width get_he_operation_channel_width(
	const struct ieee80211_he_operation *he_oper, size_t he_oper_len)
{
	enum chan_width channel_width = CHAN_WIDTH_UNKNOWN;
	const u8 *he_oper_u8 = (const u8 *) he_oper;
	bool is_6ghz_info_present, is_vht_info_present, is_cohosted_bss_present;
	size_t expected_len;

	if (he_oper_len < HE_OPERATION_ELEM_MIN_LEN)
		return channel_width;

	is_6ghz_info_present =
		he_oper->he_oper_params & HE_OPERATION_6GHZ_OPER_INFO;
	is_vht_info_present =
		he_oper->he_oper_params & HE_OPERATION_VHT_OPER_INFO;
	is_cohosted_bss_present =
		he_oper->he_oper_params & HE_OPERATION_COHOSTED_BSS;
	expected_len = HE_OPERATION_ELEM_MIN_LEN +
		(is_6ghz_info_present ? HE_OPERATION_6GHZ_OPER_INFO_LEN : 0) +
		(is_vht_info_present ? HE_OPERATION_VHT_OPER_INFO_LEN : 0) +
		(is_cohosted_bss_present ?
		 HE_OPERATION_COHOSTED_BSSID_INDICATOR_LEN : 0);

	if (he_oper_len < expected_len)
		return channel_width;

	if (is_6ghz_info_present) {
		struct ieee80211_he_6ghz_oper_info *six_ghz_oper_info =
			(struct ieee80211_he_6ghz_oper_info *)
			(he_oper_u8 + HE_OPERATION_ELEM_MIN_LEN +
			 (is_vht_info_present ?
			  HE_OPERATION_VHT_OPER_INFO_LEN : 0) +
			 (is_cohosted_bss_present ?
			  HE_OPERATION_COHOSTED_BSSID_INDICATOR_LEN : 0));

		channel_width =
			get_6ghz_operation_channel_width(six_ghz_oper_info);
	}

	if (channel_width == CHAN_WIDTH_UNKNOWN && is_vht_info_present) {
		struct ieee80211_vht_operation *vht_oper_info =
			(struct ieee80211_vht_operation *)
			(he_oper_u8 + HE_OPERATION_ELEM_MIN_LEN);

		channel_width = get_vht_operation_channel_width(vht_oper_info);
	}

	return channel_width;
}


/* Parse EHT Operation element to get EHT operation channel width */
static enum chan_width get_eht_operation_channel_width(
	const struct ieee80211_eht_operation *eht_oper, size_t eht_oper_len)
{
	if (eht_oper_len < EHT_OPERATION_ELEM_MIN_LEN + EHT_OPER_INFO_MIN_LEN ||
	    !(eht_oper->oper_params & EHT_OPER_INFO_PRESENT))
		return CHAN_WIDTH_UNKNOWN;

	switch (eht_oper->oper_info.control & EHT_OPER_CHANNEL_WIDTH_MASK) {
	case EHT_OPER_CHANNEL_WIDTH_20MHZ:
		return CHAN_WIDTH_20;
	case EHT_OPER_CHANNEL_WIDTH_40MHZ:
		return CHAN_WIDTH_40;
	case EHT_OPER_CHANNEL_WIDTH_80MHZ:
		return CHAN_WIDTH_80;
	case EHT_OPER_CHANNEL_WIDTH_160MHZ:
		return CHAN_WIDTH_160;
	case EHT_OPER_CHANNEL_WIDTH_320MHZ:
		return CHAN_WIDTH_320;
	default:
		return CHAN_WIDTH_UNKNOWN;
	}
}


/* Parse HT/VHT/HE operation elements to get operation channel width */
enum chan_width get_operation_channel_width(struct ieee802_11_elems *elems)
{
	enum chan_width channel_width = CHAN_WIDTH_UNKNOWN;
	struct ieee80211_ht_operation *ht_oper;
	struct ieee80211_vht_operation *vht_oper_info;
	struct ieee80211_he_operation *he_oper;
	struct ieee80211_eht_operation *eht_oper;

	if (!elems)
		return channel_width;

	ht_oper = (struct ieee80211_ht_operation *) elems->ht_operation;
	vht_oper_info = (struct ieee80211_vht_operation *) elems->vht_operation;
	he_oper = (struct ieee80211_he_operation *) elems->he_operation;
	eht_oper = (struct ieee80211_eht_operation *) elems->eht_operation;

	if (eht_oper)
		channel_width = get_eht_operation_channel_width(
			eht_oper, elems->eht_operation_len);

	if (channel_width == CHAN_WIDTH_UNKNOWN && he_oper)
		channel_width = get_he_operation_channel_width(
			he_oper, elems->he_operation_len);

	if (channel_width == CHAN_WIDTH_UNKNOWN && vht_oper_info)
		channel_width = get_vht_operation_channel_width(vht_oper_info);

	if (channel_width == CHAN_WIDTH_UNKNOWN && ht_oper) {
		u8 sec_chan_offset = ht_oper->ht_param &
			HT_INFO_HT_PARAM_SECONDARY_CHNL_OFF_MASK;

		channel_width = sec_chan_offset == 0 ?
			CHAN_WIDTH_20 : CHAN_WIDTH_40;
	}

	return channel_width;
}


/*
 * Get STA operation channel width from AP's operation channel width and
 * STA's supported channel width
 */
enum chan_width get_sta_operation_chan_width(
	enum chan_width ap_operation_chan_width,
	struct supported_chan_width sta_supported_chan_width)
{
	if (ap_operation_chan_width == CHAN_WIDTH_320 &&
	    sta_supported_chan_width.is_320_supported)
		return CHAN_WIDTH_320;

	if (ap_operation_chan_width == CHAN_WIDTH_160 ||
	    ap_operation_chan_width == CHAN_WIDTH_320)
		return sta_supported_chan_width.is_160_supported ?
			CHAN_WIDTH_160 : CHAN_WIDTH_80;

	if (ap_operation_chan_width == CHAN_WIDTH_80P80)
		return sta_supported_chan_width.is_80p80_supported ?
			CHAN_WIDTH_80P80 : CHAN_WIDTH_80;

	if (ap_operation_chan_width == CHAN_WIDTH_40)
		return sta_supported_chan_width.is_40_supported ?
			CHAN_WIDTH_40 : CHAN_WIDTH_20;

	return ap_operation_chan_width;
}


static const u8 channels_80mhz[] = { 42, 58, 106, 122, 138, 155 };
static const u8 channels_160mhz[] = { 50, 114, 163 };


static u8 op_class_idx_to_chan_vht(u8 op_class, u8 idx)
{
	const u8 *chans_array;
	unsigned int size;

	if (op_class == 128 || op_class == 130) {
		chans_array = channels_80mhz;
		size = ARRAY_SIZE(channels_80mhz);
	} else if (op_class == 129) {
		chans_array = channels_160mhz;
		size = ARRAY_SIZE(channels_160mhz);
	} else {
		return 0;
	}

	if (idx >= size)
		return 0;

	return chans_array[idx];
}


/**
 * op_class_idx_to_chan - Channel index in the operating class to channel number
 * @op: A pointer to the operating class object
 * @idx: The channel index within the operating class. The channels are ordered
 *	from the lowest number to the highest, index starting from 0.
 */
u8 op_class_idx_to_chan(const struct oper_class_map *op, u8 idx)
{
	u8 chan;

	if (op->bw == BW80 || op->bw == BW80P80 || op->bw == BW160)
		return op_class_idx_to_chan_vht(op->op_class, idx);

	chan = op->min_chan + idx * op->inc;
	if (chan > op->max_chan)
		return 0;

	return chan;
}


static int op_class_chan_to_idx_vht(u8 op_class, u8 chan)
{
	const u8 *chans_array;
	unsigned int i, size;

	if (op_class == 128 || op_class == 130) {
		chans_array = channels_80mhz;
		size = ARRAY_SIZE(channels_80mhz);
	} else if (op_class == 129) {
		chans_array = channels_160mhz;
		size = ARRAY_SIZE(channels_160mhz);
	} else {
		return -1;
	}

	for (i = 0; i < size; i++)
		if (chan == chans_array[i])
			return i;

	return -1;
}


/**
 * op_class_chan_to_idx - Channel number to channel index in the operating class
 * @op: A pointer to the operating class object
 * @chan: The channel number
 * Returns: Channel index or -1 if channel not found
 */
int op_class_chan_to_idx(const struct oper_class_map *op, u8 chan)
{
	if (op->bw == BW80 || op->bw == BW80P80 || op->bw == BW160)
		return op_class_chan_to_idx_vht(op->op_class, chan);

	if (chan < op->min_chan || chan > op->max_chan ||
	    (chan - op->min_chan) % op->inc)
		return -1;

	return (chan - op->min_chan) / op->inc;
}


static int get_center_freq_80mhz(int ctrl_freq)
{
	static const int center_freqs[] =
		{ 5210, 5290, 5530, 5610, 5690, 5775 };
	unsigned int i;

	for (i = 0; i < ARRAY_SIZE(center_freqs); i++) {
		if (ctrl_freq >= center_freqs[i] - 30 &&
		    ctrl_freq <= center_freqs[i] + 30)
			return center_freqs[i];
	}

	return 0;
}


static int get_center_freq_160mhz(int ctrl_freq)
{
	static const int center_freqs[] = { 5250, 5570 };
	unsigned int i;

	for (i = 0; i < ARRAY_SIZE(center_freqs); i++) {
		if (ctrl_freq >= center_freqs[i] - 70 &&
		    ctrl_freq <= center_freqs[i] + 70)
			return center_freqs[i];
	}

	return 0;
}


/**
 * ieee80211_get_center_freq - Get center frequency based on control
 *     frequency and operating class information
 *
 * @ctrl_freq: Control frequency in MHz
 * @bw: The bandwidth as defined in struct oper_class_map
 */
int ieee80211_get_center_freq(int ctrl_freq, u32 bw)
{
	switch (bw) {
	case BW20:
		return ctrl_freq;
	case BW40PLUS:
		return ctrl_freq + 10;
	case BW40MINUS:
		return ctrl_freq - 10;
	case BW80:
	case BW80P80:
		return get_center_freq_80mhz(ctrl_freq);
	case BW160:
		return get_center_freq_160mhz(ctrl_freq);
	default:
		return -1;
	}
}
